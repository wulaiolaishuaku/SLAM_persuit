#include <ros/ros.h>
#include <nav_msgs/Odometry.h>
#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/Twist.h>
#include <tf/transform_listener.h>

int main(int argc, char** argv) {
    ros::init(argc, argv, "odom_publisher");
    ros::NodeHandle nh;

    // 创建 tf listener 用于监听坐标系转换
    tf::TransformListener listener;

    // 创建发布者，发布到 /odom 话题
    ros::Publisher odom_pub = nh.advertise<nav_msgs::Odometry>("/carto_odom", 50);

    ros::Rate rate(10.0);  // 设置频率为 10Hz
    while (ros::ok()) {
        // 创建一个空的 Odometry 消息，用来接收转换后的位置
        nav_msgs::Odometry odom_msg;

        try {
            // 等待直到变换可用（从 odom 到 base_link）
            listener.waitForTransform("carto_odom", "base_link", ros::Time(0), ros::Duration(3.0));

            // 获取从 "odom" 到 "base_link" 的变换
            tf::StampedTransform transform;
            listener.lookupTransform("carto_odom", "base_link", ros::Time(0), transform);

            // 填充位置信息
            odom_msg.header.stamp = ros::Time::now();
            odom_msg.header.frame_id = "carto_odom";
            odom_msg.child_frame_id = "base_link";

            // 提取变换并填充到 Odometry 消息中
            odom_msg.pose.pose.position.x = transform.getOrigin().x();
            odom_msg.pose.pose.position.y = transform.getOrigin().y();
            odom_msg.pose.pose.position.z = transform.getOrigin().z();

            // 提取旋转信息并填充到 Odometry 消息中
            tf::Quaternion q = transform.getRotation();
            odom_msg.pose.pose.orientation.x = q.x();
            odom_msg.pose.pose.orientation.y = q.y();
            odom_msg.pose.pose.orientation.z = q.z();
            odom_msg.pose.pose.orientation.w = q.w();

            // 计算机器人的线速度和角速度
            // // 此处假设速度为 0，如果需要，可以从其他传感器获取速度数据
            // odom_msg.twist.twist.linear.x = 0.0;
            // odom_msg.twist.twist.linear.y = 0.0;
            // odom_msg.twist.twist.linear.z = 0.0;
            // odom_msg.twist.twist.angular.x = 0.0;
            // odom_msg.twist.twist.angular.y = 0.0;
            // odom_msg.twist.twist.angular.z = 0.0;

            // 发布里程计消息
            odom_pub.publish(odom_msg);

        } catch (tf::TransformException &ex) {
            ROS_ERROR("Could not get transform: %s", ex.what());
        }

        rate.sleep();
        ros::spinOnce();
    }

    return 0;
}
