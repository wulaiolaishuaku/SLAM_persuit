#include <ros/ros.h>
#include <geometry_msgs/Point.h>
#include <nav_msgs/Odometry.h>
#include <move_base_msgs/MoveBaseActionGoal.h>
#include <tf/tf.h>
#include <sensor_msgs/Imu.h>
#include <deque>

ros::Publisher odom_pub;
ros::Publisher goal_pub;  // 发布/move_base/goal
ros::Subscriber odom_sub;
ros::Subscriber sub_imu;
std::deque<geometry_msgs::Point> history_position;
nav_msgs::Odometry current_odom;  // 用于存储当前的odom
sensor_msgs::Imu current_imu;  // 用于存储当前的imu数据
ros::Time last_publish_time;  // 记录上次发布的时间
geometry_msgs::Point prev_smoothed_point;

const double alpha = 0.5; // 滤波系数，建议 0.1~0.5 之间

void initialize() {
    prev_smoothed_point.x = 0.0;
    prev_smoothed_point.y = 0.0;
    prev_smoothed_point.z = 0.0; // 如果不需要 z 值，仍需要显式赋值为 0.0
}

geometry_msgs::Point lowPassFilter(const geometry_msgs::Point& new_point) {
    geometry_msgs::Point smoothed_point;
    smoothed_point.x = alpha * new_point.x + (1 - alpha) * prev_smoothed_point.x;
    smoothed_point.y = alpha * new_point.y + (1 - alpha) * prev_smoothed_point.y;
    prev_smoothed_point = smoothed_point; // 保存当前滤波结果
    return smoothed_point;
}


double normalizeAngle(double angle) {
    while (angle > M_PI) angle -= 2 * M_PI;  // 将角度限制在 [-π, π] 范围
    while (angle < -M_PI) angle += 2 * M_PI;
    return angle;
}

void baseStationPositionCallback(const geometry_msgs::Point::ConstPtr& msg) {
    // 获取局部目标点位置
    // geometry_msgs::Point local_position = lowPassFilter(*msg);
    geometry_msgs::Point local_position = *msg;
    // 计算动态全局位置
    geometry_msgs::Point dynamic_global_position;
    double car_x = current_odom.pose.pose.position.x;
    double car_y = current_odom.pose.pose.position.y;
    // double car_theta = tf::getYaw(current_odom.pose.pose.orientation);
    double car_theta = tf::getYaw(current_imu.orientation);
    car_theta = normalizeAngle(car_theta);

    // 将局部目标点转换为全局坐标
    // 计算动态全局目标点的位置（基于当前车体位置和局部目标点）
    dynamic_global_position.x = car_x + local_position.y * cos(car_theta) -  local_position.x * sin(car_theta);
    dynamic_global_position.y = car_y + local_position.y * sin(car_theta) + local_position.x * cos(car_theta);

    // 如果想将目标点偏移1米（朝向相反方向）
    double offset_distance = 1.0;  // 偏移1米
    dynamic_global_position.x -= offset_distance * cos(car_theta);
    dynamic_global_position.y -= offset_distance * sin(car_theta);

    // 检查时间间隔
    ros::Time current_time = ros::Time::now();

    ROS_INFO("dynamic_global_position: x=%.2f, y=%.2f", dynamic_global_position.x, dynamic_global_position.y);

    // 发布动态目标点
    move_base_msgs::MoveBaseActionGoal goal_msg;
    goal_msg.header.stamp = ros::Time::now(); 
    goal_msg.goal.target_pose.header.frame_id = "map"; // 全局坐标系
    goal_msg.goal.target_pose.pose.position.x = dynamic_global_position.x;
    goal_msg.goal.target_pose.pose.position.y = dynamic_global_position.y;

    // 保持当前朝向
    goal_msg.goal.target_pose.pose.orientation.x = 0.0;
    goal_msg.goal.target_pose.pose.orientation.y = 0.0;
    goal_msg.goal.target_pose.pose.orientation.z = 0.0;
    goal_msg.goal.target_pose.pose.orientation.w = 1.0;

    // 发布目标点
    goal_pub.publish(goal_msg);

    // }
}

void odomCallback(const nav_msgs::Odometry::ConstPtr& msg) {
    // 订阅/odom话题并保存当前的全局位置
    current_odom = *msg;
}
void imuCallback(const sensor_msgs::Imu::ConstPtr& msg) {
    // 订阅/imu话题并保存当前的imu数据
    current_imu = *msg;
}
int main(int argc, char** argv) {
    ros::init(argc, argv, "add_local_to_global_position");
    ros::NodeHandle nh;
    initialize();
    // 创建发布器，发布到 /new_goal 和 /move_base/goal 话题
    odom_pub = nh.advertise<nav_msgs::Odometry>("/new_goal", 10);
    sub_imu = nh.subscribe("/handsfree/imu", 10, imuCallback);
    goal_pub = nh.advertise<move_base_msgs::MoveBaseActionGoal>("/move_base/goal", 10);  // 发布到/move_base/goal

    // 创建订阅器，订阅 /odom 和 /base_station_position 话题
    odom_sub = nh.subscribe("/odom", 10, odomCallback);
    ros::Subscriber base_station_sub = nh.subscribe("/base_station_position", 10, baseStationPositionCallback);

    ros::Rate rate(10); // 设置频率为10Hz
    ros::spin();  // 启动 ROS 事件循环
    return 0;
}
