#include <ros/ros.h>
#include <cstdlib>
#include <unistd.h>  // For sleep()

ros::Time last_reboot_time;  // 上次重启的时间
double reboot_interval = 60.0;  // 定时重启的间隔，单位：秒

// 启动Cartographer定位
void startLocalization() {
    ROS_INFO("启动Cartographer定位...");
    system("roslaunch cartographer_ros yf_demo.launch &");  // 启动Cartographer
    sleep(2);  // 等待Cartographer启动稳定，可以根据实际情况调整
}

// 杀死所有与cartographer相关的节点
void killCartographerNodes() {
    ROS_WARN("杀死所有与Cartographer相关的节点...");
    // 使用rosnode list 获取所有节点
    system("rosnode list | grep cartographer | xargs -I {} rosnode kill {}");
    sleep(1);  // 等待所有节点完全被杀死
}

int main(int argc, char** argv) {
    ros::init(argc, argv, "localization_reboot");
    ros::NodeHandle nh;

    // 初始化上一次重启的时间
    last_reboot_time = ros::Time::now();

    // 启动定位系统
    startLocalization();

    ros::Rate rate(1);  // 设定循环频率为1Hz，1秒钟检查一次
    while (ros::ok()) {
        ros::Duration elapsed_time = ros::Time::now() - last_reboot_time;
        
        // 如果时间间隔超过设定值（1分钟），则重启定位系统
        if (elapsed_time.toSec() >= reboot_interval) {
            ROS_WARN("定位系统超时，重新启动Cartographer！");
            killCartographerNodes();  // 杀死所有与Cartographer相关的节点
            startLocalization();  // 重新启动Cartographer
            last_reboot_time = ros::Time::now();  // 更新重启时间
        }
        
        ros::spinOnce();
        rate.sleep();  // 保证程序按1Hz频率循环
    }

    return 0;
}
