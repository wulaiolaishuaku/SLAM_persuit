#include <ros/ros.h>
#include <geometry_msgs/Point.h>
#include <nav_msgs/Odometry.h>
#include <move_base_msgs/MoveBaseActionGoal.h>
#include <actionlib_msgs/GoalStatusArray.h>
#include <tf/tf.h>
#include <sensor_msgs/Imu.h>
#include <deque>
#include <cmath>

// 发布器
ros::Publisher odom_pub;
ros::Publisher goal_pub;

// 订阅器
ros::Subscriber odom_sub;
ros::Subscriber sub_imu;


// 全局变量
std::deque<geometry_msgs::Point> history_position;
nav_msgs::Odometry current_odom;
sensor_msgs::Imu current_imu;
geometry_msgs::Point current_target;
geometry_msgs::Point prev_smoothed_point;
geometry_msgs::Twist current_velocity;
bool has_target = false;
bool target_failed = false;
const double alpha = 0.5;
const double threshold_distance = 0.5;
const double offset_distance = 1.0;

// 函数声明
void initialize();
geometry_msgs::Point lowPassFilter(const geometry_msgs::Point& new_point);
double normalizeAngle(double angle);
bool isTargetReached();
void publishTarget(const geometry_msgs::Point& target_position);
void handleFailedPlan();
void moveBaseStatusCallback(const actionlib_msgs::GoalStatusArray::ConstPtr& msg);

// 初始化滤波参数
void initialize() {
    prev_smoothed_point.x = 0.0;
    prev_smoothed_point.y = 0.0;
    prev_smoothed_point.z = 0.0;
}

// 低通滤波器
geometry_msgs::Point lowPassFilter(const geometry_msgs::Point& new_point) {
    geometry_msgs::Point smoothed_point;
    smoothed_point.x = alpha * new_point.x + (1 - alpha) * prev_smoothed_point.x;
    smoothed_point.y = alpha * new_point.y + (1 - alpha) * prev_smoothed_point.y;
    prev_smoothed_point = smoothed_point;
    return smoothed_point;
}

// 将角度归一化到 [-π, π]
double normalizeAngle(double angle) {
    while (angle > M_PI) angle -= 2 * M_PI;
    while (angle < -M_PI) angle += 2 * M_PI;
    return angle;
}

// 检查是否到达目标点
bool isTargetReached() {
    double car_x = current_odom.pose.pose.position.x;
    double car_y = current_odom.pose.pose.position.y;
    double distance = sqrt(pow(current_target.x - car_x, 2) + pow(current_target.y - car_y, 2));
    return distance < threshold_distance;
}

// 发布目标点到 /move_base/goal
void publishTarget(const geometry_msgs::Point& target_position) {
    move_base_msgs::MoveBaseActionGoal goal_msg;
    goal_msg.header.stamp = ros::Time::now();
    goal_msg.goal.target_pose.header.frame_id = "map";

    goal_msg.goal.target_pose.pose.position.x = target_position.x;
    goal_msg.goal.target_pose.pose.position.y = target_position.y;
// 保持当前朝向
    goal_msg.goal.target_pose.pose.orientation.x = 0.0;
    goal_msg.goal.target_pose.pose.orientation.y = 0.0;
    goal_msg.goal.target_pose.pose.orientation.z = 0.0;
    goal_msg.goal.target_pose.pose.orientation.w = 1.0;
    goal_pub.publish(goal_msg);
    ROS_INFO("Published target position: x=%.2f, y=%.2f", target_position.x, target_position.y);
}

// 处理目标点转换
void baseStationPositionCallback(const geometry_msgs::Point::ConstPtr& msg) {
    geometry_msgs::Point local_position = lowPassFilter(*msg);

    geometry_msgs::Point new_global_position;
    double car_x = current_odom.pose.pose.position.x;
    double car_y = current_odom.pose.pose.position.y;
    double car_theta = tf::getYaw(current_odom.pose.pose.orientation);
    car_theta = normalizeAngle(car_theta);

    new_global_position.x = car_x + local_position.y * cos(car_theta) - local_position.x * sin(car_theta);
    new_global_position.y = car_y + local_position.y * sin(car_theta) + local_position.x * cos(car_theta);

    new_global_position.x -= offset_distance * cos(car_theta);
    new_global_position.y -= offset_distance * sin(car_theta);

    if (!has_target || isTargetReached() || target_failed == true) {
        current_target = new_global_position;
        has_target = true;
        target_failed = false;  // 重置失败标志
        publishTarget(current_target);
    }
    else 
    {
        publishTarget(current_target);
    }
}

void cmdVelCallback(const geometry_msgs::Twist::ConstPtr& msg) {    
    current_velocity = *msg;
    if (current_velocity.linear.x == 0.0 )
    {
        target_failed = true;  // 重置失败标志
    }
    else
    {
        target_failed = false;  // 重置失败标志
    }
}

// 订阅 /odom 数据
void odomCallback(const nav_msgs::Odometry::ConstPtr& msg) {
    current_odom = *msg;
}

// 订阅 /imu 数据
void imuCallback(const sensor_msgs::Imu::ConstPtr& msg) {
    current_imu = *msg;
}

// 主函数
int main(int argc, char** argv) {
    ros::init(argc, argv, "add_local_to_global_position");
    ros::NodeHandle nh;
    initialize();

    // 发布器
    odom_pub = nh.advertise<nav_msgs::Odometry>("/new_goal", 10);
    goal_pub = nh.advertise<move_base_msgs::MoveBaseActionGoal>("/move_base/goal", 10); 
    ros::Subscriber cmd_vel_sub = nh.subscribe("/cmd_vel", 10, cmdVelCallback);
    // 订阅器
    odom_sub = nh.subscribe("/odom", 10, odomCallback);
    sub_imu = nh.subscribe("/handsfree/imu", 10, imuCallback);
    ros::Subscriber base_station_sub = nh.subscribe("/base_station_position", 10, baseStationPositionCallback);
    

    ros::Rate rate(10);
    while (ros::ok()) {
        ros::spinOnce();
        rate.sleep();
    }
    return 0;
}
