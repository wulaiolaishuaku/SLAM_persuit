#include <ros/ros.h>
#include <geometry_msgs/PointStamped.h>
#include <nav_msgs/Odometry.h>
#include <tf2/LinearMath/Quaternion.h>
#include <tf2/LinearMath/Matrix3x3.h>
#include <geometry_msgs/PoseStamped.h>
#include <eigen3/Eigen/Dense> 
#include <deque> 
#include <nav_msgs/OccupancyGrid.h>
#include <queue>
#include <std_msgs/UInt32.h>
/*低通滤波：
公式：y = α*x + (1-α)*y_prev
抑制高频噪声，适合慢变信号
参数α越小，平滑效果越强

滑动平均：
维护最近N个数据点的窗口
对窗口内数据取平均
窗口越大平滑效果越好，但延迟增加

异常值检测：
计算当前点与上一点的欧氏距离
超过阈值视为异常点（默认0.5米）
丢弃异常点保持轨迹连续*/

struct FilterConfig {
    bool use_lowpass = true;     // 使用低通滤波
    bool use_moving_avg = false; // 使用滑动平均
    double lowpass_alpha = 0.2;  // 低通滤波系数(0-1], 越小越平滑
    int moving_window = 5;       // 滑动窗口大小
    double max_step = 2.5;       // 最大允许步长(米)
}config;
bool allow_publish = true;
std::mutex status_mutex;
nav_msgs::Odometry current_odom; 
ros::Publisher uwb_odom_pub;
ros::Publisher nav_goal_pub;
// 障碍物调整参数
const int OBSTACLE_THRESHOLD = 65;  // 代价地图障碍物阈值
const int MAX_SEARCH_RADIUS = 20;   // 最大搜索半径（栅格数）
nav_msgs::OccupancyGrid::ConstPtr current_costmap;
void odomCallback(const nav_msgs::Odometry::ConstPtr& msg) {
    current_odom = *msg; 
    // ROS_INFO("ODOM:%f,%f",current_odom.pose.pose.position.x ,current_odom.pose.pose.position.y );
}

// 历史数据缓存
std::deque<geometry_msgs::PoseStamped> pose_history;
Eigen::Vector2d last_filtered(0, 0);

// 初始化参数
void init_params(ros::NodeHandle& nh) {
    nh.param("lowpass_alpha", config.lowpass_alpha, 0.2);
    nh.param("moving_window", config.moving_window, 5);
    nh.param("max_step", config.max_step, 2.5);
    nh.param("use_lowpass", config.use_lowpass, true);
    nh.param("use_moving_avg", config.use_moving_avg, false);
}

void tagStatusCallback(const std_msgs::UInt32::ConstPtr& msg) {
    std::lock_guard<std::mutex> lock(status_mutex);
    allow_publish = (msg->data % 2 == 0); //偶数为true,奇数为false
    ROS_INFO_COND(allow_publish, "Publishing ENABLED (even number)");
    ROS_INFO_COND(!allow_publish, "Publishing DISABLED (odd number)");
}

void costmapCallback(const nav_msgs::OccupancyGrid::ConstPtr& msg) {
    current_costmap = msg;
}

// 低通滤波实现
Eigen::Vector2d lowpass_filter(const Eigen::Vector2d& current) {
    if (last_filtered.isZero()) return current;
    return last_filtered * (1 - config.lowpass_alpha) + current * config.lowpass_alpha;
}

// 滑动平均实现
Eigen::Vector2d moving_average_filter(const Eigen::Vector2d& current) {
    pose_history.push_back(geometry_msgs::PoseStamped());
    pose_history.back().pose.position.x = current.x();
    pose_history.back().pose.position.y = current.y();
    
    if (pose_history.size() > config.moving_window) {
        pose_history.pop_front();
    }
    
    Eigen::Vector2d sum(0, 0);
    for (const auto& p : pose_history) {
        sum.x() += p.pose.position.x;
        sum.y() += p.pose.position.y;
    }
    return sum / pose_history.size();
}

// 异常值检测
bool is_valid_point(const Eigen::Vector2d& prev, const Eigen::Vector2d& current) {
    double dx = current.x() - prev.x();
    double dy = current.y() - prev.y();
    return (dx*dx + dy*dy) < (config.max_step * config.max_step);
}
/*BFS的原理，按层扩展，先搜索最近的栅格，确保找到的第一个可行点是最接近原始点的。visited数组的作用是避免重复访问同一个栅格，提高效率，防止无限循环
第1轮搜索：检查目标点本身（发现不可行）
 ❌
第2轮搜索：检查周围8个相邻栅格
 □ □ □
□ ❌ □ 
`□ □ □
第3轮搜索：扩展至更外围（找到第一个可行点★）
□ □ □ □
□ □ □ □
□ □ ★ □
□ □ □ □
返回结果：将★的位置作为修正后的目标点
*/
geometry_msgs::PoseStamped adjustPosition(const geometry_msgs::PoseStamped& original_pose) {
    geometry_msgs::PoseStamped adjusted = original_pose;
    // 获取代价地图参数
    const double res = current_costmap->info.resolution; // 分辨率
    const double origin_x = current_costmap->info.origin.position.x; //地图原点坐标
    const double origin_y = current_costmap->info.origin.position.y;
    const int width = current_costmap->info.width; // 地图宽度
    const int height = current_costmap->info.height; // 地图高度

    // 转换到栅格坐标
    int start_x = static_cast<int>((original_pose.pose.position.x - origin_x) / res);
    int start_y = static_cast<int>((original_pose.pose.position.y - origin_y) / res);

    // BFS队列 先进先出
    std::queue<std::pair<int, int>> search_queue; //搜索队列
    std::vector<std::vector<bool>> visited(width, std::vector<bool>(height, false)); //标记访问
    
    search_queue.push({start_x, start_y}); //初始点入队
    visited[start_x][start_y] = true; 

    // 8方向搜索
    const int dx[] = {-1, 0, 1, -1, 1, -1, 0, 1};
    const int dy[] = {-1, -1, -1, 0, 0, 1, 1, 1};

    while (!search_queue.empty()) {
        auto current = search_queue.front(); //访问队列中第一个元素
        search_queue.pop();

        // 检查当前栅格是否有效，不超过地图范围
        if (current.first >= 0 && current.first < width && 
            current.second >= 0 && current.second < height) {
            
            int index = current.second * width + current.first;
            
            // 找到第一个可通行区域
            if (current_costmap->data[index] <= OBSTACLE_THRESHOLD) {
                // 转换回世界坐标（使用栅格中心）
                adjusted.pose.position.x = origin_x + (current.first + 0.5) * res;
                adjusted.pose.position.y = origin_y + (current.second + 0.5) * res;
                ROS_WARN("Adjusted position to: (%.2f, %.2f)", 
                        adjusted.pose.position.x, adjusted.pose.position.y);
                return adjusted;
            }

            // 扩展搜索，放入队列
            for (int i = 0; i < 8; ++i) {
                int nx = current.first + dx[i];
                int ny = current.second + dy[i];
                
                if (nx >= 0 && nx < width && ny >= 0 && ny < height && !visited[nx][ny]) {
                    visited[nx][ny] = true;
                    search_queue.push({nx, ny});
                }
            }
        }
    }

    ROS_ERROR("Could not find valid position, using original");
    return original_pose;
}

void uwbCallback(const geometry_msgs::Point::ConstPtr& msg) {
    static Eigen::Vector2d last_valid(0, 0);
    tf2::Quaternion q(
        current_odom.pose.pose.orientation.x,
        current_odom.pose.pose.orientation.y,
        current_odom.pose.pose.orientation.z,
        current_odom.pose.pose.orientation.w);
    q.normalize();
    double roll, pitch, yaw;
    tf2::Matrix3x3(q).getRPY(roll, pitch, yaw);
    // 沿航向方向偏移一米
    // double offset_x = -cos(yaw);  // 负号表示向后偏移
    // double offset_y = -sin(yaw);  // 负号表示向后偏移
    // ROS_INFO("YAW:%f",yaw);
    // 创建发布消息
    geometry_msgs::PoseStamped tag_pose;
    tag_pose.header.stamp = ros::Time::now();  // 添加时间戳
    tag_pose.header.frame_id = current_odom.header.frame_id; // 坐标系一致
    tag_pose.pose.position.x = current_odom.pose.pose.position.x 
                             + msg->x * cos(yaw) - msg->y * sin(yaw);
    // ROS_INFO("X,%f",tag_pose.pose.position.x);
    tag_pose.pose.position.y = current_odom.pose.pose.position.y 
                             + msg->x * sin(yaw) + msg->y * cos(yaw) ;
                            //  ROS_INFO("y,%f",tag_pose.pose.position.y) ;
    // ROS_INFO("x,y:%f,%f",msg->x,msg->y);
    tag_pose.pose.orientation = current_odom.pose.pose.orientation;
    Eigen::Vector2d current_pos(tag_pose.pose.position.x, tag_pose.pose.position.y);

    if (!last_valid.isZero() && !is_valid_point(last_valid, current_pos)) {
        ROS_WARN("Detected outlier: (%.2f, %.2f)", current_pos.x(), current_pos.y());
        return;
    }
     // 应用滤波
     if (config.use_lowpass) {
        current_pos = lowpass_filter(current_pos);
        last_filtered = current_pos;
    }
    if (config.use_moving_avg) {
        current_pos = moving_average_filter(current_pos);
    }
    // 更新历史数据
    last_valid = current_pos;
    geometry_msgs::PoseStamped filtered_pose;
    filtered_pose.header.stamp = ros::Time::now();  // 添加时间戳
    filtered_pose.header.frame_id = "map"; // 坐标系一致
    filtered_pose.pose.position.x = current_pos.x();
    filtered_pose.pose.position.y = current_pos.y();
    filtered_pose.pose.orientation.x = 0;
    filtered_pose.pose.orientation.y = 0;
    filtered_pose.pose.orientation.z = 0;
    filtered_pose.pose.orientation.w = 1.0;
     // 障碍物检测和调整
    if (current_costmap) {
        // 转换到代价地图坐标系
        const double x = filtered_pose.pose.position.x;
        const double y = filtered_pose.pose.position.y;
        const double origin_x = current_costmap->info.origin.position.x;
        const double origin_y = current_costmap->info.origin.position.y;
        const double res = current_costmap->info.resolution;
        const int width = current_costmap->info.width;
        const int height = current_costmap->info.height;

        // 计算栅格坐标
        int cell_x = static_cast<int>((x - origin_x) / res);
        int cell_y = static_cast<int>((y - origin_y) / res);

        // 检查是否在障碍物中
        bool is_obstacle = false;
        if (cell_x >= 0 && cell_x < width && cell_y >= 0 && cell_y < height) {
            int index = cell_y * width + cell_x;
            is_obstacle = (current_costmap->data[index] > OBSTACLE_THRESHOLD);
        } else {
            is_obstacle = true;  // 超出地图范围视为障碍
        }
        bool current_allow = false;
        {
            std::lock_guard<std::mutex> lock(status_mutex);
            current_allow = allow_publish;
        }
        if (current_allow)
        {
            // 执行位置调整
            if (is_obstacle) {
                geometry_msgs::PoseStamped safe_pose = adjustPosition(filtered_pose);
                // ROS_INFO("adjustPosition:%f,%f",safe_pose.pose.position.x,safe_pose.pose.position.y);
                nav_goal_pub.publish(safe_pose);
            } else {
                nav_goal_pub.publish(filtered_pose);
            }
        }
        else{
            geometry_msgs::PoseStamped odom_pose;
            odom_pose.header.stamp = ros::Time::now();  // 添加时间戳
            odom_pose.header.frame_id = "map"; // 坐标系一致
            odom_pose.pose.position.x = current_odom.pose.pose.position.x ;
            odom_pose.pose.position.y = current_odom.pose.pose.position.y;
            odom_pose.pose.orientation.x = 0;
            odom_pose.pose.orientation.y = 0;
            odom_pose.pose.orientation.z = 0;
            odom_pose.pose.orientation.w = 1.0;
            nav_goal_pub.publish(odom_pose);
        }
    }
}

int main(int argc, char** argv) {
    ros::init(argc, argv, "simple_uwb_mapper");
    ros::NodeHandle nh;
    nh.param("max_step", config.max_step, 2.5);
    uwb_odom_pub = nh.advertise<geometry_msgs::PoseStamped>("/uwb_position_odom", 10);
    ros::Subscriber sub1 = nh.subscribe("/carto_odom", 10, odomCallback);
    ros::Subscriber sub2 = nh.subscribe("/base_station_position", 10, uwbCallback);
    ros::Subscriber costmap_sub = nh.subscribe("/move_base/global_costmap/costmap", 1, costmapCallback);
    nav_goal_pub = nh.advertise<geometry_msgs::PoseStamped>("/move_base_simple/goal", 1);
    ros::Subscriber status_sub = nh.subscribe("/tag_status_count", 10, tagStatusCallback);
    ros::spin();
    return 0;
}