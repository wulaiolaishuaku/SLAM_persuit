#ifndef MAP_EDITING_TOOL_H
#define MAP_EDITING_TOOL_H

#include <rviz/tool.h>
#include <geometry_msgs/PointStamped.h>
#include <ros/ros.h>
#include <rviz/viewport_mouse_event.h>
#include <OGRE/OgreVector3.h>
#include <OGRE/OgreViewport.h>
#include <OGRE/OgreCamera.h>
#include <visualization_msgs/Marker.h>
namespace map_editing_tool {

class MapEditingTool : public rviz::Tool {
//   Q_OBJECT
public:
  MapEditingTool();
  virtual ~MapEditingTool() = default;

  virtual void onInitialize();
  virtual void activate();
  virtual void deactivate();
  virtual int processMouseEvent(rviz::ViewportMouseEvent& event);

private:
  ros::NodeHandle nh_;
  ros::Publisher coord_pub_;
  ros::Publisher marker_pub_;
};

} // namespace map_editing_tool

#endif