// map_rviz_plugin.h
#ifndef MAP_RVIZ_PLUGIN_H
#define MAP_RVIZ_PLUGIN_H

#include <rviz/panel.h>
#include <ros/ros.h>
#include <nav_msgs/OccupancyGrid.h>
#include <geometry_msgs/PointStamped.h>
#include <std_srvs/Empty.h>
#include <QLayout>
#include <QPushButton>
#include <QSlider>
#include <visualization_msgs/Marker.h>
#include <rviz/render_panel.h>
namespace map_editing {

class Map_Editing : public rviz::Panel {
Q_OBJECT
public:
  Map_Editing(QWidget* parent = 0);
  virtual void load(const rviz::Config& config);
  virtual void save(rviz::Config config) const;

private Q_SLOTS:
  void startEditingMap();
  void finishEditingMap();
  void setDrawLineMode();
  void saveMap();

private:
  enum DrawMode { NONE, LINE };
  
  // UI components
  QVBoxLayout* layout_;
  QPushButton* start_edit_button_;
  QPushButton* finish_edit_button_;
  QPushButton* draw_line_button_;
  QPushButton* erase_button_;
  QSlider* erase_radius_slider_;
  rviz::RenderPanel* render_panel_;
  
  // ROS components
  ros::NodeHandle nh_;
  ros::Publisher map_pub_;
  ros::Publisher marker_pub_;
  ros::Subscriber map_sub_;
  ros::Subscriber coord_sub_;
  ros::ServiceClient clear_costmap_client_;
  
  // State variables
  bool is_editing_map_;
  bool is_dragging_;
  bool erase_mode_;
  bool is_line_drawing_;
  DrawMode draw_mode_;
  nav_msgs::OccupancyGrid current_map_;
  geometry_msgs::Point line_start_point_;
  std::vector<geometry_msgs::Point> drawing_points_;

  // Core functions
  void mapCallback(const nav_msgs::OccupancyGrid::ConstPtr& msg);
  void coordCallback(const geometry_msgs::PointStamped::ConstPtr& msg);
  void publishEditedMap();
  void generateLinePoints(const geometry_msgs::Point& start, const geometry_msgs::Point& end);
  void handleMouseDrag(const QPoint& position);
  void updateMap();
  void publishDrawing();

  // Event handlers
  virtual void mousePressEvent(QMouseEvent* event);
  virtual void mouseMoveEvent(QMouseEvent* event);
  virtual void mouseReleaseEvent(QMouseEvent* event);
};

} // namespace map_editing

#endif