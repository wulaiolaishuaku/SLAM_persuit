#include "map_editing_tool/map_editing_panel.h"
#include <QMouseEvent>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QLabel>
#include <ros/package.h>
#include <fstream>
#include <QFileDialog>
#include <boost/filesystem.hpp> 
#include <std_srvs/Empty.h>  
#include <visualization_msgs/Marker.h>
#include <rviz/viewport_mouse_event.h>
#include <rviz/render_panel.h>
namespace map_editing {

    Map_Editing::Map_Editing(QWidget *parent) : Panel(parent), is_editing_map_(false), is_dragging_(false), draw_mode_(NONE),erase_mode_(false) {
        
        layout_ = new QVBoxLayout; 
        render_panel_ = new rviz::RenderPanel(this);
        layout_->addWidget(render_panel_);
    
        start_edit_button_ = new QPushButton("Start Editing Map", this);
        layout_->addWidget(start_edit_button_);

       
        finish_edit_button_ = new QPushButton("Finish Editing Map", this);
        finish_edit_button_->setEnabled(false);  // 默认不可用，因为用户需要先点击 "Start Editing Map" 才能进入编辑模式。
        layout_->addWidget(finish_edit_button_);

        draw_line_button_ = new QPushButton("Draw Line", this);
        layout_->addWidget(draw_line_button_);
     
        
        erase_button_ = new QPushButton("Erase", this);
        layout_->addWidget(erase_button_);
        setLayout(layout_);
        
        erase_radius_slider_ = new QSlider(Qt::Horizontal, this);
        erase_radius_slider_->setRange(1, 50); 
        erase_radius_slider_->setValue(6);     
        layout_->addWidget(new QLabel("Erase Radius:"));
        layout_->addWidget(erase_radius_slider_);
       
        QPushButton* save_button_ = new QPushButton("Save_Map", this);
        layout_->addWidget(save_button_);
        connect(save_button_, &QPushButton::clicked, this, &Map_Editing::saveMap);
      
        connect(erase_radius_slider_, &QSlider::valueChanged, this, [this](int value) {
        ROS_WARN("Erase radius changed to: %.2f m", value * current_map_.info.resolution);
        });
        
        connect(start_edit_button_, &QPushButton::clicked, this, &Map_Editing::startEditingMap);
        connect(finish_edit_button_, &QPushButton::clicked, this, &Map_Editing::finishEditingMap);
        connect(draw_line_button_, &QPushButton::clicked, this, &Map_Editing::setDrawLineMode);
        connect(erase_button_, &QPushButton::clicked, this, [this]() { 
            erase_mode_ = true; 
            draw_mode_ = NONE; // 确保划线模式关闭
            ROS_WARN("Erase mode ON");
          });
        // map_pub_ = nh_.advertise<nav_msgs::OccupancyGrid>("/map", 10);
        marker_pub_ = nh_.advertise<visualization_msgs::Marker>("/drawing_marker", 10);
        map_sub_ = nh_.subscribe("/map", 1, &Map_Editing::mapCallback, this);
        map_pub_ = nh_.advertise<nav_msgs::OccupancyGrid>("/map", 10);
        coord_sub_ = nh_.subscribe("/map_edit_coord", 10, &Map_Editing::coordCallback, this);
    }
    void Map_Editing::saveMap() {
     
        if (current_map_.info.width == 0 || current_map_.info.height == 0) {
          ROS_ERROR("fail to save!");
          return;
        }
        
   
        const std::string save_dir = "/home/orangepi/Downloads";
        const std::string base_name = "mymap";
        const std::string pgm_path = save_dir + "/" + base_name + ".pgm";
        const std::string yaml_path = save_dir + "/" + base_name + ".yaml";
      
    
        if (!boost::filesystem::exists(save_dir)) {
          boost::filesystem::create_directories(save_dir);
        }
      
        try {
     
          std::ofstream pgm_file(pgm_path.c_str());
          pgm_file << "P5\n# CREATOR: map_rviz_plugin\n";
          pgm_file << current_map_.info.width << " " << current_map_.info.height << "\n255\n";
          
          for (unsigned int y = 0; y < current_map_.info.height; y++) {
            for (unsigned int x = 0; x < current_map_.info.width; x++) {
              const int index = x + (current_map_.info.height - y - 1) * current_map_.info.width;
              const char value = current_map_.data[index] == 0 ? 254 : 
                                current_map_.data[index] == 100 ? 0 : 205;
              pgm_file << value;
            }
          }
          pgm_file.close();
      
        
          std::ofstream yaml_file(yaml_path.c_str());
          yaml_file << "image: " << base_name << ".pgm\n"  
                    << "resolution: " << current_map_.info.resolution << "\n"
                    << "origin: [" << current_map_.info.origin.position.x << ", " 
                    << current_map_.info.origin.position.y << ", 0.0]\n"
                    << "negate: 0\n"
                    << "occupied_thresh: 0.65\n"
                    << "free_thresh: 0.196\n";
          yaml_file.close();
      
          ROS_WARN("have saved:\n- %s\n- %s", pgm_path.c_str(), yaml_path.c_str());
        } catch (const std::exception& e) {
          ROS_ERROR("saved failed: %s", e.what());
        }
      }
    
    void Map_Editing::coordCallback(const geometry_msgs::PointStamped::ConstPtr &msg) {
        if (is_editing_map_) {
         
          if (erase_mode_){
                // const float erase_radius = 0.3; 
                const float erase_radius = erase_radius_slider_->value() * current_map_.info.resolution;
                const int erase_value = 0;      
          
                const float x = msg->point.x;
                const float y = msg->point.y;
                const int map_x = (x - current_map_.info.origin.position.x) / current_map_.info.resolution;
                const int map_y = (y - current_map_.info.origin.position.y) / current_map_.info.resolution;
            
                const int radius_pixels = static_cast<int>(erase_radius / current_map_.info.resolution);
            
            
                for (int dx = -radius_pixels; dx <= radius_pixels; ++dx) {
                    for (int dy = -radius_pixels; dy <= radius_pixels; ++dy) {
                    if (dx*dx + dy*dy > radius_pixels*radius_pixels) continue; 
                    
                    const int px = map_x + dx;
                    const int py = map_y + dy;
                    
                    if (px >= 0 && px < current_map_.info.width && 
                        py >= 0 && py < current_map_.info.height) {
                        const int index = py * current_map_.info.width + px;
                        // const int flipped_py = current_map_.info.height - py - 1;
                        // const int index = flipped_py * current_map_.info.width + px;
                        current_map_.data[index] = erase_value;
                        // if (current_map_.data[index] == 0) {
                        //   ROS_WARN("Erased obstacle at (%d, %d)", px, py);
                        //   current_map_.data[index] = 0; // 确保设置为0（自由空间）
                        // }
                    }
                    }
                }
            
                publishEditedMap();
                ROS_WARN("Erased area at (%d, %d) with radius %d pixels", map_x, map_y, radius_pixels);
          }
          else if(draw_mode_ == LINE){
            if (!is_line_drawing_) {
         
                line_start_point_ = msg->point;
                is_line_drawing_ = true;
                ROS_WARN("Line start at: (%.2f, %.2f)", line_start_point_.x, line_start_point_.y);
              } else {
              
                const geometry_msgs::Point& end_point = msg->point;
                generateLinePoints(line_start_point_, end_point);
                updateMap();
                is_line_drawing_ = false;
                ROS_WARN("Line end at: (%.2f, %.2f)", end_point.x, end_point.y);
              }
            }
          }
      }
      void Map_Editing::generateLinePoints(const geometry_msgs::Point& start, const geometry_msgs::Point& end) {
        int x0 = (start.x - current_map_.info.origin.position.x) / current_map_.info.resolution;
        int y0 = (start.y - current_map_.info.origin.position.y) / current_map_.info.resolution;
        int x1 = (end.x - current_map_.info.origin.position.x) / current_map_.info.resolution;
        int y1 = (end.y - current_map_.info.origin.position.y) / current_map_.info.resolution;
    
        int dx = abs(x1 - x0);
        int dy = abs(y1 - y0);
        int sx = x0 < x1 ? 1 : -1;
        int sy = y0 < y1 ? 1 : -1;
        int err = dx - dy;
    
        while (true) {
            if (x0 >= 0 && x0 < current_map_.info.width && 
                y0 >= 0 && y0 < current_map_.info.height) {
                int index = y0 * current_map_.info.width + x0;
                current_map_.data[index] = 100; // 设置为障碍物
            }
    
            if (x0 == x1 && y0 == y1) break;
            int e2 = 2 * err;
            if (e2 > -dy) {
                err -= dy;
                x0 += sx;
            }
            if (e2 < dx) {
                err += dx;
                y0 += sy;
            }
        }
    }
    void Map_Editing::load(const rviz::Config &config) {
        Panel::load(config);
    }

    void Map_Editing::save(rviz::Config config) const {
        Panel::save(config);
    }

    void Map_Editing::startEditingMap() {
        is_editing_map_ = true;
        finish_edit_button_->setEnabled(true); 
        ROS_WARN("Start editing map.");
    }

    void Map_Editing::finishEditingMap() {
        is_editing_map_ = false;
        finish_edit_button_->setEnabled(false); 
        publishEditedMap();
        ROS_WARN("Finish editing map.");
    }

    void Map_Editing::setDrawLineMode() {
        draw_mode_ = LINE;
        erase_mode_ = false;  
        ROS_WARN("Set draw line mode.");
    }

  
    void Map_Editing::mapCallback(const nav_msgs::OccupancyGrid::ConstPtr &msg) {
        current_map_ = *msg;
    }

    void Map_Editing::publishEditedMap() {
        ROS_WARN("Publishing updated map...");
        map_pub_.publish(current_map_);
    }

    void Map_Editing::publishDrawing() {
        visualization_msgs::Marker marker;

       
        marker.header.frame_id = "map"; 
        marker.header.stamp = ros::Time::now();

       
        marker.ns = "drawing";
        marker.id = 0;

        
        marker.type = visualization_msgs::Marker::LINE_STRIP;

    
        marker.action = visualization_msgs::Marker::ADD;

        marker.scale.x = 0.1; 

        
        marker.color.r = 0.0;
        marker.color.g = 1.0; 
        marker.color.b = 0.0;
        marker.color.a = 1.0; 

     
        marker.points = drawing_points_;

        
        marker.lifetime = ros::Duration();

        
        marker_pub_.publish(marker);
    }

    void Map_Editing::updateMap() {
        for (const auto& point : drawing_points_) {
          // 转像素坐标
            int map_x = static_cast<int>((point.x - current_map_.info.origin.position.x) / current_map_.info.resolution);
            int map_y = static_cast<int>((point.y - current_map_.info.origin.position.y) / current_map_.info.resolution);
          // 检查坐标是否在地图范围内
            if (map_x >= 0 && map_x < current_map_.info.width && map_y >= 0 && map_y < current_map_.info.height) {
              // 计算一维数组索引
                int index = map_y * current_map_.info.width + map_x;
                //设置为障碍物
                current_map_.data[index] = 100; 
            }
        }

        // 更新地图
        publishEditedMap();
    }

    void Map_Editing::mousePressEvent(QMouseEvent* event) {
      if (is_editing_map_ && event->button() == Qt::LeftButton) {
        // 获取鼠标点击位置的Ray
        Ogre::Ray ray = render_panel_->getCamera()->getCameraToViewportRay(
            event->x() / static_cast<float>(render_panel_->width()),
            event->y() / static_cast<float>(render_panel_->height()));
    
        // 假设地图在Z=0平面上，计算Ray与Z=0平面的交点
        Ogre::Plane plane(Ogre::Vector3::UNIT_Z, 0);
        std::pair<bool, Ogre::Real> intersection = ray.intersects(plane);
        if (intersection.first) {
          Ogre::Vector3 pos = ray.getPoint(intersection.second);
          geometry_msgs::Point point;
          point.x = pos.x;
          point.y = pos.y;
          point.z = 0;
          drawing_points_.push_back(point);
          is_dragging_ = true;
        }
      }
    }
    
    void Map_Editing::mouseMoveEvent(QMouseEvent* event) {
      if (is_editing_map_ && is_dragging_) {
        // 获取鼠标移动位置的Ray
        Ogre::Ray ray = render_panel_->getCamera()->getCameraToViewportRay(
            event->x() / static_cast<float>(render_panel_->width()),
            event->y() / static_cast<float>(render_panel_->height()));
    
        // 假设地图在Z=0平面上，计算Ray与Z=0平面的交点
        Ogre::Plane plane(Ogre::Vector3::UNIT_Z, 0);
        std::pair<bool, Ogre::Real> intersection = ray.intersects(plane);
        if (intersection.first) {
          Ogre::Vector3 pos = ray.getPoint(intersection.second);
          geometry_msgs::Point point;
          point.x = pos.x;
          point.y = pos.y;
          point.z = 0;
          drawing_points_.push_back(point);
          publishDrawing();
          updateMap();
        }
      }
    }

    void Map_Editing::mouseReleaseEvent(QMouseEvent *event) {
        if (is_editing_map_ && event->button() == Qt::LeftButton) {
            is_dragging_ = false;
        }
    }

    void Map_Editing::handleMouseDrag(const QPoint& position) {
        if (is_editing_map_) {
            geometry_msgs::Point point;
            point.x = position.x();
            point.y = position.y();
            point.z = 0;
            drawing_points_.push_back(point); 
            publishDrawing(); 
            updateMap();
        }
    }
}

#include <pluginlib/class_list_macros.h>
PLUGINLIB_EXPORT_CLASS(map_editing::Map_Editing, rviz::Panel)  