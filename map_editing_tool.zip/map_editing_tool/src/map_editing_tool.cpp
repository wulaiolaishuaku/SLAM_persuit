// map_editing_tool.cpp
#include "map_editing_tool/map_editing_tool.h"
#include <ros/ros.h>

namespace map_editing_tool  {
MapEditingTool::MapEditingTool() {
  ros::NodeHandle nh;
  coord_pub_ = nh.advertise<geometry_msgs::PointStamped>("/map_edit_coord", 10);
  marker_pub_ = nh.advertise<visualization_msgs::Marker>("/map_edit_markers", 10);
}

void MapEditingTool::onInitialize() {
  // 初始化工具
}

void MapEditingTool::activate() {
  // 激活时显示提示
  ROS_INFO("Map Editing Tool Activated");
}

void MapEditingTool::deactivate() {}

int MapEditingTool::processMouseEvent(rviz::ViewportMouseEvent &event) {
  if (event.leftDown()) {
    // 1. 坐标标准化
    Ogre::Real screenX = event.x / static_cast<Ogre::Real>(event.viewport->getActualWidth());
    Ogre::Real screenY = event.y / static_cast<Ogre::Real>(event.viewport->getActualHeight());

    // 2. 生成视口射线（正确参数版本）
    Ogre::Ray ray;
    event.viewport->getCamera()->getCameraToViewportRay(screenX, screenY, &ray);

    // 3. 计算与地面平面(Z=0)的交点
    Ogre::Plane groundPlane(Ogre::Vector3::UNIT_Z, 0.0f);
    std::pair<bool, Ogre::Real> intersection = ray.intersects(groundPlane);

    if (intersection.first) {
      // 4. 获取精确的世界坐标
      Ogre::Vector3 worldPos = ray.getPoint(intersection.second);

      // 5. 发布坐标
      geometry_msgs::PointStamped coord;
      coord.header.frame_id = "map";
      coord.header.stamp = ros::Time::now();
      coord.point.x = worldPos.x;
      coord.point.y = worldPos.y;
      coord.point.z = 0.0;
      coord_pub_.publish(coord);
    }
  }
  return rviz::Tool::Render;
}
}

#include <pluginlib/class_list_macros.h>
PLUGINLIB_EXPORT_CLASS(map_editing_tool::MapEditingTool, rviz::Tool)
