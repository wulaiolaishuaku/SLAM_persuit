#include <ros/ros.h>
#include <geometry_msgs/Twist.h>
#include <stdint.h>
#include <cmath>
#include <serial/serial.h>
#include <std_msgs/Float32MultiArray.h>
// ros::Publisher pub ;
// 电机控制协议帧结构体
typedef struct
{
    uint8_t SOF1 = 0x5A;               // 帧头，固定为0x5A
    uint8_t length = 0x11;             // 数据长度，固定为0x11（16字节）
    uint8_t Motor_type = 0x01;         // 电机类型，暂时固定为0x01
    uint8_t lenb = 0x01;               // 使能，暂时固定为0x01
    uint8_t l_speedl;                  // 左轮速度低字节
    uint8_t l_speedh;                  // 左轮速度高字节
    uint8_t ldir;                      // 左轮方向，0顺时针，1逆时针
    uint8_t renb = 0x01;               // 使能，暂时固定为0x01
    uint8_t r_speedl;                  // 右轮速度低字节
    uint8_t r_speedh;                  // 右轮速度高字节
    uint8_t rdir;                      // 右轮方向，0顺时针，1逆时针
    uint8_t mod = 0x00;                // 固定为0x00
    uint8_t motor_switch = 0x00;       // 固定为0x00
    uint8_t electric_current = 0x05;   // 固定为0x05
    uint8_t Voltage_Current = 59;      // 固定为59（电压系数）
    uint8_t suml;                      // CRC低字节
    uint8_t sumh;                      // CRC高字节
} motor_tx;
typedef struct
{
   uint8_t SOF_H;                    //0xA5
   uint8_t SOF_L;                    //0x18
   uint8_t driver_state;             //设备状态
   uint8_t error;                    //故障码
   uint8_t left_motor_speed_L;       //左电机速度低字节
   uint8_t left_motor_speed_H;       //左电机速度高字节
   uint8_t left_motor_direction;     //左电机运动方向
   uint8_t right_motor_speed_L;      //右电机速度低字节
   uint8_t right_motor_speed_H;      //右电机速度高字节
   uint8_t right_motor_direction;    //右电机运动方向
   uint8_t right_motor_encoder_L;    //右电机编码器低位
   uint8_t right_motor_encoder_H;    //右电机编码器高位
   uint8_t left_motor_encoder_L;     //左电机里程计低位
   uint8_t left_motor_encoder_H;     //左电机里程计高位
   uint8_t left_motor_pid_out_L;     //左电机闭环切换开环时的PID输出     开环切换闭环根据速度
   uint8_t left_motor_pid_out_H;     //左电机闭环切换开环时的PID输出
   uint8_t right_motor_pid_out_L;    //右电机闭环切换开环时的PID输出     开环切换闭环根据速度
   uint8_t right_motor_pid_out_H;    //右电机闭环切换开环时的PID输出
   uint8_t month;                    //月
   uint8_t day;                      //日
   uint8_t software_version_H;       //软件版本号高位
   uint8_t software_version_L;       //软件版本号低位
   uint8_t crc_L;                    //crc低位
   uint8_t crc_H;                    //crc高位
}motor_rx1;
ros::Publisher pub;
// 轮径和减速比
#define WHEEL_DIAMETER 300.0  // mm
#define REDUCTION_RATIO 4.64  // 无单位

// 转速计算函数，将 m/s 转换为转/分钟 (RPM)
float mps_to_rpm(float speed_mps) {
    float speed_mms = speed_mps * 1000.0;  // 将 m/s 转换为 mm/s
    float perimeter = WHEEL_DIAMETER * 3.1415;  // 轮周长，单位 mm
    // return (speed_mms) / (perimeter * REDUCTION_RATIO) * 60;  // 转换为转/分钟 (RPM)
    return (speed_mms) / (perimeter ) * 60 * REDUCTION_RATIO;
    // return (speed_mms) / (perimeter ) * 60 * 2.5;
}

// CRC16 校验函数
uint16_t ModbusCrc16Cal(uint8_t *DataPtr, uint16_t DataCnt) {
    uint16_t CrcWord = 0xFFFF;
    uint8_t CrcI;
    while (DataCnt--) {
        CrcWord ^= (uint16_t)*DataPtr++;
        for (CrcI = 0; CrcI < 8; CrcI++) {
            if (CrcWord & 0x0001) {
                CrcWord >>= 1;
                // CRC16 Polynomial = X16 + X15 + X2 + 1
                CrcWord ^= 0xA001;
            } else {
                CrcWord >>= 1;
            }
        }
    }
    return CrcWord;
}

// 串口发送数据函数
void sendToMotorDriver(motor_tx* tx_buf, const std::string& port) {
    try {
        serial::Serial ser;
        ser.setPort(port);  // 设置串口
        ser.setBaudrate(19200);  // 设置波特率

        // 创建一个 Timeout 对象并设置超时
        serial::Timeout timeout = serial::Timeout::simpleTimeout(1000);
        ser.setTimeout(timeout);  // 设置超时

        ser.open();  // 打开串口

        if (ser.isOpen()) {
            ROS_INFO("Serial port opened successfully...");
            // 发送数据
            std::vector<uint8_t> data;
            data.push_back(tx_buf->SOF1);  // 添加帧头
            data.push_back(tx_buf->length);  // 添加数据长度
            data.push_back(tx_buf->Motor_type);  // 电机类型
            data.push_back(tx_buf->lenb);  // 使能
            data.push_back(tx_buf->l_speedl);  // 左轮速度低字节
            data.push_back(tx_buf->l_speedh);  // 左轮速度高字节
            data.push_back(tx_buf->ldir);  // 左轮方向
            data.push_back(tx_buf->renb);  // 右轮使能
            data.push_back(tx_buf->r_speedl);  // 右轮速度低字节
            data.push_back(tx_buf->r_speedh);  // 右轮速度高字节
            data.push_back(tx_buf->rdir);  // 右轮方向
            data.push_back(tx_buf->mod);  // 固定值0x00
            data.push_back(tx_buf->motor_switch);  // 固定值0x00
            data.push_back(tx_buf->electric_current);  // 运行电流固定值0x05
            data.push_back(tx_buf->Voltage_Current);  // 电压系数 固定值59
            data.push_back(tx_buf->suml);  // CRC低字节校验位
            data.push_back(tx_buf->sumh);  // CRC高字节

            // 发送数据
            ser.write(data);
            ROS_INFO("Data sent to motor driver");
        } else {
            ROS_ERROR("Failed to open serial port");
        }
    } catch (serial::IOException& e) {
        ROS_ERROR("Serial communication error: %s", e.what());
    }
}

// 回调函数，处理 cmd_vel 消息
void cmdVelCallback(const geometry_msgs::Twist::ConstPtr& msg, const std::string& port) {
    // motor_tx tx_buf;
    // float wheel_base = 0.446;  // 车轮间距
    // float factor = 1.5;        // 转向权重调整因子
    // float max_wheel_speed = 90.0;  // 最大轮速限制

    // // 调整后的角速度和线速度
    // float adjusted_angular = msg->angular.z * factor;
    // // 设置帧头和固定参数
    // tx_buf.SOF1 = 0x5A;    // 帧头
    // tx_buf.length = 0x11;  // 数据长度（固定为0x11）
    // tx_buf.Motor_type = 0x01;  // 电机类型（固定）
    // tx_buf.lenb = 1;  // 使能，固定为1
    // tx_buf.renb = 1;  // 使能，固定为1
    // tx_buf.mod = 0;   // 固定为0
    // tx_buf.motor_switch = 0;  // 固定为0
    // tx_buf.electric_current = 5;  // 固定为5
    // tx_buf.Voltage_Current = 59;  // 固定为59
    // //定义最大速度限制
    // const float MAX_WHEEL_SPEED_RPM=90.0;
    // // // 计算左轮和右轮的速度（转换为 mm/s 后再转换为 RPM）
    // float left_speed = mps_to_rpm(msg->linear.x + adjusted_angular * wheel_base / 2.0);  // 左轮速度
    // float right_speed = mps_to_rpm(msg->linear.x - adjusted_angular * wheel_base / 2.0); // 右轮线速度
    // // float left_speed = mps_to_rpm(msg->linear.x + msg->angular.z * wheel_base / 2);  // 左轮线速度,0.446为车轮间距
    // // float right_speed = mps_to_rpm(msg->linear.x - msg->angular.z * wheel_base / 2); // 右轮速度,0.446为车轮间距
    // printf("计算后的右轮速度=%.2f RPM\n", right_speed);  // 打印右轮速度
    // printf("计算后的左轮速度=%.2f RPM\n", left_speed);  // 打印左轮速度

    // // 检查是否超速
    // float max_speed = std::max(fabs(left_speed), fabs(right_speed));
    // if (max_speed > max_wheel_speed) {
    //     float scale = max_wheel_speed / max_speed;
    //     left_speed *= scale;
    //     right_speed *= scale;
    //     printf("超速限制，缩放比例：%.2f\n", scale);
    //     printf("调整后的左轮速度=%.2f RPM\n", left_speed);
    //     printf("调整后的右轮速度=%.2f RPM\n", right_speed);
    // }
    
    motor_tx tx_buf;
    float wheel_base = 0.446;  // 车轮间距
    float factor = 1.5;        // 转向权重调整因子
    float max_wheel_speed = 90.0;  // 最大轮速限制
    float alpha = 0.8;         // 滤波系数
    float k = 1.5; // 调整转弯差速放大系数
    std_msgs::Float32MultiArray speed_msg;
    // 平滑输入
    static float prev_linear = 0.0, prev_angular = 0.0;
    float smooth_linear = alpha * msg->linear.x + (1 - alpha) * prev_linear;
    float smooth_angular = alpha * msg->angular.z + (1 - alpha) * prev_angular;
    prev_linear = smooth_linear;
    prev_angular = smooth_angular;

    // 动态调整角速度
    float adjusted_angular = smooth_angular * factor;
    // float adjusted_angular = smooth_angular ;
    // if (fabs(msg->angular.z) <= 0.15) {  // 阈值根据需要调整 
    //     adjusted_angular = 0.0;
    // }
    // else{
    //     adjusted_angular = smooth_angular * factor;
    // }
    // float R = (adjusted_angular == 0) ? 1e6 : smooth_linear / adjusted_angular;
    float R = (fabs(adjusted_angular) <= 0.03) ? 1e6 : smooth_linear / adjusted_angular;
    // 使用改进的轮速模型
    float left_speed = mps_to_rpm(smooth_linear  *(R + k*wheel_base / 2.0) / R);
    float right_speed = mps_to_rpm(smooth_linear  *(R - k*wheel_base / 2.0) / R);
    printf("计算后的右轮速度=%.2f RPM\n", right_speed);  // 打印右轮速度
    printf("计算后的左轮速度=%.2f RPM\n", left_speed);  // 打印左轮速度
    // 计算轮速
    // float left_speed = mps_to_rpm(smooth_linear + adjusted_angular * wheel_base / 2.0);
    // float right_speed = mps_to_rpm(smooth_linear - adjusted_angular * wheel_base / 2.0);
    // 超速限制
    float max_speed = std::max(fabs(left_speed), fabs(right_speed));
    if (max_speed > max_wheel_speed) {
        float scale = max_wheel_speed / max_speed;
        left_speed *= scale;
        right_speed *= scale;
        printf("超速限制，缩放比例：%.2f\n", scale);
        printf("调整后的左轮速度=%.2f RPM\n", left_speed);
        printf("调整后的右轮速度=%.2f RPM\n", right_speed);
    }
    // //发布速度到/motor_speed话题
    speed_msg.data.resize(2);
    speed_msg.data[0] = left_speed;
    speed_msg.data[1] = right_speed;
    pub.publish(speed_msg);
    // 转换为低字节和高字节
    tx_buf.l_speedl = (uint8_t)((uint16_t)(fabs(left_speed)) & 0xFF);
    tx_buf.l_speedh = (uint8_t)((uint16_t)(fabs(left_speed)) >> 8);
    tx_buf.r_speedl = (uint8_t)((uint16_t)(fabs(right_speed)) & 0xFF);
    tx_buf.r_speedh = (uint8_t)((uint16_t)(fabs(right_speed)) >> 8);

    // // 设置电机方向（根据速度正负判断）
    tx_buf.ldir = (left_speed >= 0) ? 1: 0;  // 顺时针为0，逆时针为1
    tx_buf.rdir = (right_speed >= 0) ? 0: 1;

    // tx_buf.ldir=1;
    // tx_buf.rdir=0;

    // 计算CRC校验
    uint16_t crc = ModbusCrc16Cal((uint8_t*)&tx_buf, sizeof(tx_buf) - 2); // 计算CRC，忽略CRC字段本身
    tx_buf.suml = (uint8_t)(crc & 0xFF);  // CRC低字节

    tx_buf.sumh = (uint8_t)((crc >> 8) & 0xFF);  // CRC高字节

    // 打印调试信息
    ROS_INFO("Sending motor command: SOF1=0x%02X, length=0x%02X, left_speed=%.2f, right_speed=%.2f", 
             tx_buf.SOF1, tx_buf.length, left_speed, right_speed);

    // 发送数据到底盘
    sendToMotorDriver(&tx_buf, port);  
}

int main(int argc, char** argv) {
    ros::init(argc, argv, "motor_control_node");
    ros::NodeHandle nh;

    std::string port = "/dev/ttyUSB1";  // 串口号，需根据实际情况修改
    // 订阅 cmd_vel 话题
    ros::Subscriber sub = nh.subscribe<geometry_msgs::Twist>("/cmd_vel", 10, boost::bind(cmdVelCallback, _1, port));
    //把left_speed，right_speed速度发布到一个话题
    // ros::Publisher pub = nh.advertise<std_msgs::Float32MultiArray>("/motor_speed", 10);
    // ros::Rate loop_rate(10);
    pub =nh.advertise<std_msgs::Float32MultiArray>("/motor_speed", 10);


    ros::spin();
    return 0;
}
