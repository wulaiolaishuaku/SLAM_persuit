#include <ros/ros.h>
#include <geometry_msgs/Twist.h>
#include <nav_msgs/Odometry.h>
#include <serial/serial.h>
#include <cstdint>
#include <vector>
#include <cmath>
#include<std_msgs/Float32MultiArray.h>
// 串口实例
serial::Serial ser;
ros::Publisher encoder_pub_;

// 校验和计算函数
uint8_t calculateChecksum(const uint8_t* data, size_t len) {
    uint8_t checksum = 0;
    for (size_t i = 0; i < len; ++i) {
        checksum += data[i];
    }
    return checksum;
}

// 全局变量：机器人的当前位置和朝向
double x = 0.0, y = 0.0, theta = 0.0;
double wheel_base = 0.5;  // 轮距，单位：米
double wheel_radius = 0.1;  // 轮子半径，单位：米
int PPR_left = 3791;  // 左电机每圈脉冲数
int PPR_right = 3658;  // 右电机每圈脉冲数

// 速度控制回调函数
void cmdVelCallback(const geometry_msgs::Twist::ConstPtr& msg) {
    // 构造指令数据包
    uint8_t data[13] = {0xAA, 0x55}; // 包头
    data[2] = 0x01;                  // 默认地址
    data[3] = 0x02;                  // CMD: 整体速度控制模式
    data[4] = 0x04;                  // 数据长度

    // 线速度 (int16, 单位 mm/s)
    int16_t linear_velocity = static_cast<int16_t>(msg->linear.x * 1000); // m/s 转 mm/s
    data[5] = (linear_velocity >> 8) & 0xFF;
    data[6] = linear_velocity & 0xFF;

    // 角速度 (int16, 单位 0.001 rad/s)
    int16_t angular_velocity = static_cast<int16_t>(-msg->angular.z * 1000); // rad/s 转 0.001 rad/s
    data[7] = (angular_velocity >> 8) & 0xFF;
    data[8] = angular_velocity & 0xFF;

    // 功能配置位 (Bit1=1: 运行状态)
    data[9] = 0x02;

    // 保留位
    data[10] = 0x00;

    // 校验和
    data[11] = calculateChecksum(data, 11);

    // 包尾
    data[12] = 0xCC;

    // 通过串口发送指令
    if (ser.isOpen()) {
        ser.write(data, sizeof(data));
        ROS_INFO("Sent control command: linear=%.3f m/s, angular=%.3f rad/s",
                 msg->linear.x, msg->angular.z);
    } else {
        ROS_WARN("Serial port not open. Cannot send control command.");
    }
}

// 从心跳包数据中提取编码器和速度信息
void parseHeartbeatData(const std::vector<uint8_t>& data) {
    if (data.size() < 36) {
        ROS_WARN("Received data is too short.");
        return;
    }

    // 提取电机1和电机2的编码器数据
    int16_t encoder_1 = (static_cast<int16_t>(data[5]) << 8) | data[6];
    int16_t encoder_2 = (static_cast<int16_t>(data[7]) << 8) | data[8];
    std_msgs::Float32MultiArray encoder_msg;
    encoder_msg.data.clear(); // 清空之前的数据
    encoder_msg.data.push_back(static_cast<float>(encoder_1));
    encoder_msg.data.push_back(static_cast<float>(encoder_2));
    encoder_pub_.publish(encoder_msg);
   
}

// 处理串口数据
void readSerialData() {
    if (ser.available()) {
        std::vector<uint8_t> data;
        ser.read(data, ser.available());

        // 检查数据包头是否为0xAA 0x55
        if (data.size() > 1 && data[0] == 0xAA && data[1] == 0x55) {
            parseHeartbeatData(data);
        }
    }
}

int main(int argc, char** argv) {
    // 初始化 ROS 节点
    ros::init(argc, argv, "cmd_vel_to_serial");
    ros::NodeHandle nh;

    // 串口初始化
    try {
        ser.setPort("/dev/ttyUSB1");  // 根据实际情况设置串口名称
        ser.setBaudrate(115200);
        serial::Timeout to = serial::Timeout::simpleTimeout(1000);
        ser.setTimeout(to);
        ser.open();
    } catch (serial::IOException& e) {
        ROS_ERROR("Unable to open port.");
        return -1;
    }

    if (ser.isOpen()) {
        ROS_INFO("Serial port initialized.");
    } else {
        return -1;
    }

    // 订阅 /cmd_vel 话题
    ros::Subscriber cmd_vel_sub = nh.subscribe("/cmd_vel", 10, cmdVelCallback);

    // 里程计发布器
    encoder_pub_ = nh.advertise<std_msgs::Float32MultiArray>("bianmaqi", 10);

    // ROS 循环
    ros::Rate loop_rate(50);  // 50Hz 更新频率
    while (ros::ok()) {
        // 读取串口数据s
        readSerialData();
        ros::spinOnce();
        loop_rate.sleep();
    }

    // 关闭串口
    ser.close();
    return 0;
}
