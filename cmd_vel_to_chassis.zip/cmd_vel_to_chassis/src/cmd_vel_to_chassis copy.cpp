#include <ros/ros.h>
#include <geometry_msgs/Twist.h>
#include <stdint.h>
#include <cmath>
#include <serial/serial.h>
#include <std_msgs/Float32MultiArray.h>
#include <nav_msgs/Odometry.h>
#include <tf/tf.h>
// ros::Publisher pub ;
double pos_x;
double pos_y ;
double target_pos_x;
double target_pos_y ;
float distance_to_target;
float target_theta;
float delta_theta;
float left_speed_pid;
float right_speed_pid;
float d_yaw=0;
float i_yaw=0;
float last_yaw_error=0;
float prev_yaw = 0.0;  // 前一次的偏航角
float current_yaw = 0.0;  // 当前的偏航角
float prev_time ;  // 前一次的时间戳
float current_angular_velocity ;  
float prev_pos_x = 0.0;
float prev_pos_y = 0.0;
float current_linear_velocity ;
float current_v_left ;
float current_v_right ;
float k_vel_d_r = 0.85;
float k_vel_d_l = 0.9;
float k_vel_p = 0.05;
float kp_yaw = 1.2;
float kd_yaw = 1.2;
float wheel_base = 0.446;
float left_speed ;
float right_speed ;
// 电机控制协议帧结构体
typedef struct
{
    uint8_t SOF1 = 0x5A;               // 帧头，固定为0x5A
    uint8_t length = 0x11;             // 数据长度，固定为0x11（16字节）
    uint8_t Motor_type = 0x01;         // 电机类型，暂时固定为0x01
    uint8_t lenb = 0x01;               // 使能，暂时固定为0x01
    uint8_t l_speedl;                  // 左轮速度低字节
    uint8_t l_speedh;                  // 左轮速度高字节
    uint8_t ldir;                      // 左轮方向，0顺时针，1逆时针
    uint8_t renb = 0x01;               // 使能，暂时固定为0x01
    uint8_t r_speedl;                  // 右轮速度低字节
    uint8_t r_speedh;                  // 右轮速度高字节
    uint8_t rdir;                      // 右轮方向，0顺时针，1逆时针
    uint8_t mod = 0x00;                // 固定为0x00
    uint8_t motor_switch = 0x00;       // 固定为0x00
    uint8_t electric_current = 0x05;   // 固定为0x05
    uint8_t Voltage_Current = 59;      // 固定为59（电压系数）
    uint8_t suml;                      // CRC低字节
    uint8_t sumh;                      // CRC高字节
} motor_tx;

ros::Publisher pub;
// 轮径和减速比
#define WHEEL_DIAMETER 300.0  // mm
#define REDUCTION_RATIO 4.64  // 无单位

// 转速计算函数，将 m/s 转换为转/分钟 (RPM)
float mps_to_rpm(float speed_mps) {
    float speed_mms = speed_mps * 1000.0;  // 将 m/s 转换为 mm/s
    float perimeter = WHEEL_DIAMETER * 3.1415;  // 轮周长，单位 mm
    // return (speed_mms) / (perimeter * REDUCTION_RATIO) * 60;  // 转换为转/分钟 (RPM)
    return (speed_mms) / (perimeter ) * 60 * REDUCTION_RATIO;
    // return (speed_mms) / (perimeter ) * 60 * 2.5;
}

// CRC16 校验函数
uint16_t ModbusCrc16Cal(uint8_t *DataPtr, uint16_t DataCnt) {
    uint16_t CrcWord = 0xFFFF;
    uint8_t CrcI;
    while (DataCnt--) {
        CrcWord ^= (uint16_t)*DataPtr++;
        for (CrcI = 0; CrcI < 8; CrcI++) {
            if (CrcWord & 0x0001) {
                CrcWord >>= 1;
                // CRC16 Polynomial = X16 + X15 + X2 + 1
                CrcWord ^= 0xA001;
            } else {
                CrcWord >>= 1;
            }
        }
    }
    return CrcWord;
}

// 串口发送数据函数
void sendToMotorDriver(motor_tx* tx_buf, const std::string& port) {
    try {
        serial::Serial ser;
        ser.setPort(port);  // 设置串口
        ser.setBaudrate(19200);  // 设置波特率

        // 创建一个 Timeout 对象并设置超时
        serial::Timeout timeout = serial::Timeout::simpleTimeout(1000);
        ser.setTimeout(timeout);  // 设置超时
    
        ser.open();  // 打开串口

        if (ser.isOpen()) {
            ROS_INFO("Serial port opened successfully...");
            // 发送数据
            std::vector<uint8_t> data;
            data.push_back(tx_buf->SOF1);  // 添加帧头
            data.push_back(tx_buf->length);  // 添加数据长度
            data.push_back(tx_buf->Motor_type);  // 电机类型
            data.push_back(tx_buf->lenb);  // 使能
            data.push_back(tx_buf->l_speedl);  // 左轮速度低字节
            data.push_back(tx_buf->l_speedh);  // 左轮速度高字节
            data.push_back(tx_buf->ldir);  // 左轮方向
            data.push_back(tx_buf->renb);  // 右轮使能
            data.push_back(tx_buf->r_speedl);  // 右轮速度低字节
            data.push_back(tx_buf->r_speedh);  // 右轮速度高字节
            data.push_back(tx_buf->rdir);  // 右轮方向
            data.push_back(tx_buf->mod);  // 固定值0x00
            data.push_back(tx_buf->motor_switch);  // 固定值0x00
            data.push_back(tx_buf->electric_current);  // 运行电流固定值0x05
            data.push_back(tx_buf->Voltage_Current);  // 电压系数 固定值59
            data.push_back(tx_buf->suml);  // CRC低字节校验位
            data.push_back(tx_buf->sumh);  // CRC高字节

            // 发送数据
            ser.write(data);
            ROS_INFO("Data sent to motor driver");
        } else {
            ROS_ERROR("Failed to open serial port");
        }
    } catch (serial::IOException& e) {
        ROS_ERROR("Serial communication error: %s", e.what());
    }
}

// 回调函数，处理 cmd_vel 消息
void cmdVelCallback(const geometry_msgs::Twist::ConstPtr& msg, const std::string& port) {
    // motor_tx tx_buf;
    // float wheel_base = 0.446;  // 车轮间距
    // float factor = 1.5;        // 转向权重调整因子
    // float max_wheel_speed = 90.0;  // 最大轮速限制

    // // 调整后的角速度和线速度
    // float adjusted_angular = msg->angular.z * factor;
    // // 设置帧头和固定参数
    // tx_buf.SOF1 = 0x5A;    // 帧头
    // tx_buf.length = 0x11;  // 数据长度（固定为0x11）
    // tx_buf.Motor_type = 0x01;  // 电机类型（固定）
    // tx_buf.lenb = 1;  // 使能，固定为1
    // tx_buf.renb = 1;  // 使能，固定为1
    // tx_buf.mod = 0;   // 固定为0
    // tx_buf.motor_switch = 0;  // 固定为0
    // tx_buf.electric_current = 5;  // 固定为5
    // tx_buf.Voltage_Current = 59;  // 固定为59
    // //定义最大速度限制
    // const float MAX_WHEEL_SPEED_RPM=90.0;
    // // // 计算左轮和右轮的速度（转换为 mm/s 后再转换为 RPM）
    // float left_speed = mps_to_rpm(msg->linear.x + adjusted_angular * wheel_base / 2.0);  // 左轮速度
    // float right_speed = mps_to_rpm(msg->linear.x - adjusted_angular * wheel_base / 2.0); // 右轮线速度
    // // float left_speed = mps_to_rpm(msg->linear.x + msg->angular.z * wheel_base / 2);  // 左轮线速度,0.446为车轮间距
    // // float right_speed = mps_to_rpm(msg->linear.x - msg->angular.z * wheel_base / 2); // 右轮速度,0.446为车轮间距
    // printf("计算后的右轮速度=%.2f RPM\n", right_speed);  // 打印右轮速度
    // printf("计算后的左轮速度=%.2f RPM\n", left_speed);  // 打印左轮速度

    // // 检查是否超速
    // float max_speed = std::max(fabs(left_speed), fabs(right_speed));
    // if (max_speed > max_wheel_speed) {
    //     float scale = max_wheel_speed / max_speed;
    //     left_speed *= scale;
    //     right_speed *= scale;
    //     printf("超速限制，缩放比例：%.2f\n", scale);
    //     printf("调整后的左轮速度=%.2f RPM\n", left_speed);
    //     printf("调整后的右轮速度=%.2f RPM\n", right_speed);
    // }
    
    motor_tx tx_buf;
    float factor = 1.5;        // 转向权重调整因子
    float max_wheel_speed = 90.0;  // 最大轮速限制
    float alpha = 0.8;         // 滤波系数
    float k = 1.5; // 调整转弯差速放大系数
    
    std_msgs::Float32MultiArray speed_msg;
    // 平滑输入
    static float prev_linear = 0.0, prev_angular = 0.0;
    float smooth_linear = alpha * msg->linear.x + (1 - alpha) * prev_linear;
    float smooth_angular = alpha * msg->angular.z + (1 - alpha) * prev_angular;
    prev_linear = smooth_linear;
    prev_angular = smooth_angular;

    // 动态调整角速度
    // float adjusted_angular = smooth_angular * factor;
    // float adjusted_angular = smooth_angular ;
    float adjusted_angular = current_angular_velocity + kp_yaw * (delta_theta)  + kd_yaw *(smooth_angular - current_angular_velocity);
    
    // if (fabs(msg->angular.z) <= 0.15) {  // 阈值根据需要调整 
    //     adjusted_angular = 0.0;
    // }
    // else{
    //     adjusted_angular = smooth_angular * factor;
    // }
    // float R = (adjusted_angular == 0) ? 1e6 : smooth_linear / adjusted_angular;
    float R = (fabs(adjusted_angular) <= 0.04) ? 1e6 : smooth_linear / adjusted_angular;
    float target_v_left = smooth_linear + (smooth_angular * wheel_base / 2.0);
    float target_v_right = smooth_linear - (smooth_angular * wheel_base / 2.0);
    // float target_v_left = smooth_linear + (adjusted_angular * wheel_base / 2.0);
    // float target_v_right = smooth_linear - (adjusted_angular * wheel_base / 2.0);
    float pos_error_x = target_pos_x - pos_x;
    float pos_error_y = target_pos_y - pos_y;
    printf("pos_error_x=%.2f,pos_error_y=%.2f\n",pos_error_x,pos_error_y);
    // float v_left = current_v_left + k_vel_p * pos_error_x + k_vel_p * pos_error_y + k_vel_d * (target_v_left - current_v_left);                                                                  
    // float v_right = current_v_right + k_vel_p * pos_error_x + k_vel_p * pos_error_y + k_vel_d * (target_v_right - current_v_right);
    // if (fabs(pos_error_x)>0.5 &&fabs(pos_error_y)>0.5){
    //     float v_left = current_v_left + k_vel_p * pos_error_x + k_vel_p * pos_error_y + k_vel_d_l * (target_v_left - current_v_left);                                                                  
    //     float v_right = current_v_right + k_vel_p * pos_error_x + k_vel_p * pos_error_y + k_vel_d_r * (target_v_right - current_v_right);
    //     printf("v_left=%.2f,v_right=%.2f\n",v_left,v_right);
    //     // float left_speed = mps_to_rpm(smooth_linear  *(R + wheel_base / 2.0) / R);
    //     // float right_speed = mps_to_rpm(smooth_linear  *(R - wheel_base / 2.0) / R);
    //     left_speed = mps_to_rpm(v_left);
    //     right_speed = mps_to_rpm(v_right);                                                                                                
    //     printf("右轮速度=%.2f RPM\n", right_speed);  // 打印右轮速度
    //     printf("左轮速度=%.2f RPM\n", left_speed);  // 打印左轮速度
    //     float max_speed1 = std::max(fabs(left_speed), fabs(right_speed));                       
    //     if (max_speed1 > max_wheel_speed) {
    //         float scale = max_wheel_speed / max_speed1;
    //         left_speed *= scale;
    //         right_speed *= scale;
    //         ROS_INFO("over speed limit, scale: %.2f", scale);
    //         ROS_INFO("adjusted left speed: %.2f RPM", left_speed);                                                                          
    //         ROS_INFO("adjusted right speed: %.2f RPM", right_speed);                                                                                                                                                                                                                                
    //     }
    // }
    // else{
    //     left_speed =0;
    //     right_speed =0;
    //     printf("pos_error_x=%.2f,pos_error_y=%.2f\n",pos_error_x,pos_error_y);
    // }
    float v_left = current_v_left + k_vel_p * pos_error_x + k_vel_p * pos_error_y + k_vel_d_l * (target_v_left - current_v_left);                                                                  
    float v_right = current_v_right + k_vel_p * pos_error_x + k_vel_p * pos_error_y + k_vel_d_r * (target_v_right - current_v_right);
    printf("v_left=%.2f,v_right=%.2f\n",v_left,v_right);
    // float left_speed = mps_to_rpm(smooth_linear  *(R + wheel_base / 2.0) / R);
    // float right_speed = mps_to_rpm(smooth_linear  *(R - wheel_base / 2.0) / R);
    left_speed = mps_to_rpm(v_left);
    right_speed = mps_to_rpm(v_right);                                                                                                
    printf("右轮速度=%.2f RPM\n", right_speed);  // 打印右轮速度
    printf("左轮速度=%.2f RPM\n", left_speed);  // 打印左轮速度
    float max_speed1 = std::max(fabs(left_speed), fabs(right_speed));                       
    if (max_speed1 > max_wheel_speed) {
        float scale = max_wheel_speed / max_speed1;
        left_speed *= scale;
        right_speed *= scale;
        ROS_INFO("over speed limit, scale: %.2f", scale);
        ROS_INFO("adjusted left speed: %.2f RPM", left_speed);                                                                          
        ROS_INFO("adjusted right speed: %.2f RPM", right_speed);                                                                                                                                                                                                                                
    }
    speed_msg.data.resize(2);
    speed_msg.data[0] = left_speed;
    speed_msg.data[1] = right_speed;
    pub.publish(speed_msg);
    tx_buf.l_speedl = (uint8_t)((uint16_t)(fabs(left_speed)) & 0xFF);
    tx_buf.l_speedh = (uint8_t)((uint16_t)(fabs(left_speed)) >> 8);
    tx_buf.r_speedl = (uint8_t)((uint16_t)(fabs(right_speed)) & 0xFF);
    tx_buf.r_speedh = (uint8_t)((uint16_t)(fabs(right_speed)) >> 8);

    // // 设置电机方向（根据速度正负判断）
    tx_buf.ldir = (left_speed >= 0) ? 1: 0;  // 顺时针为0，逆时针为1
    tx_buf.rdir = (right_speed >= 0) ? 0: 1;

    // tx_buf.ldir=1;
    // tx_buf.rdir=0;

    // 计算CRC校验
    uint16_t crc = ModbusCrc16Cal((uint8_t*)&tx_buf, sizeof(tx_buf) - 2); // 计算CRC，忽略CRC字段本身
    tx_buf.suml = (uint8_t)(crc & 0xFF);  // CRC低字节

    tx_buf.sumh = (uint8_t)((crc >> 8) & 0xFF);  // CRC高字节

    // 打印调试信息
    ROS_INFO("Sending motor command: SOF1=0x%02X, length=0x%02X, left_speed=%.2f, right_speed=%.2f", 
             tx_buf.SOF1, tx_buf.length, left_speed, right_speed);

    // 发送数据到底盘
    sendToMotorDriver(&tx_buf, port);  
}



// void odometryCallback(const nav_msgs::Odometry::ConstPtr& msg) {

//     float current_time = ros::Time::now().toSec();
//     pos_x = msg->pose.pose.position.x;
//     pos_y = msg->pose.pose.position.y;
//     current_yaw = tf::getYaw(msg->pose.pose.orientation);//获取当前的角度
//     // 处理角度跨越 ±π 的问题
//     float delta_yaw = current_yaw - prev_yaw;
//     if (delta_yaw > M_PI) {
//         delta_yaw -= 2 * M_PI;
//     } else if (delta_yaw < -M_PI) {
//         delta_yaw += 2 * M_PI;
//     }

//     // 计算时间间隔
//     float delta_time = current_time - prev_time;
//     float delta_x=pos_x - prev_pos_x;
//     float delta_y=pos_y - prev_pos_y;
//     // 避免时间间隔为零的情况
//     if (delta_time > 0.0) {
//         // 计算角速度
//         current_angular_velocity = delta_yaw / delta_time;
//         current_linear_velocity = sqrt(delta_x * delta_x + delta_y * delta_y) / delta_time;
//     }
//     //float delta_x=pos_x - prev_pos_x;
//     //float delta_y=pos_y - prev_pos_y;
//     //current_linear_velocity = sqrt(delta_x * delta_x + delta_y * delta_y) / delta_time;
//     // 更新前一次数据
//     prev_yaw = current_yaw;
//     prev_time = current_time;
//     current_v_left = current_linear_velocity + (current_angular_velocity * wheel_base / 2.0);
//     current_v_right = current_linear_velocity - (current_angular_velocity * wheel_base / 2.0);
//     ROS_INFO("Current Linear Velocity: %.2f m/s", current_linear_velocity);
//     // 打印当前角速度
//     ROS_INFO("Current angular velocity: %.2f rad/s", current_angular_velocity);
//     // printf("当前的角度=%.2f\n", current_yaw);
// }

void odometryCallback(const nav_msgs::Odometry::ConstPtr& msg) {
    // 获取当前时间
    float current_time = ros::Time::now().toSec();

    // 静态变量初始化标志
    static bool is_initialized = false;
    if (!is_initialized) {
        // 初始化 prev_* 变量
        prev_time = current_time;
        prev_pos_x = msg->pose.pose.position.x;
        prev_pos_y = msg->pose.pose.position.y;
        prev_yaw = tf::getYaw(msg->pose.pose.orientation);
        is_initialized = true;
        ROS_INFO("Initialized odometry callback.");
        return; // 第一次回调仅初始化，不计算速度
    }

    // 提取当前位置信息
    pos_x = msg->pose.pose.position.x;
    pos_y = msg->pose.pose.position.y;
    current_yaw = tf::getYaw(msg->pose.pose.orientation); // 获取当前的角度

    // 处理角度跨越 ±π 的问题
    float delta_yaw = current_yaw - prev_yaw;
    if (delta_yaw > M_PI) {
        delta_yaw -= 2 * M_PI;
    } else if (delta_yaw < -M_PI) {
        delta_yaw += 2 * M_PI;
    }

    // 计算时间间隔
    float delta_time = current_time - prev_time;

    // 计算位置变化
    float delta_x = pos_x - prev_pos_x;
    float delta_y = pos_y - prev_pos_y;

    // 避免时间间隔为零的情况
    if (delta_time > 1e-6) {
        // 计算角速度和线速度
        current_angular_velocity = delta_yaw / delta_time;
        current_linear_velocity = sqrt(delta_x * delta_x + delta_y * delta_y) / delta_time;
    } else {
        current_angular_velocity = 0.0;
        current_linear_velocity = 0.0;
    }

    // 更新左右轮速度
    current_v_left = current_linear_velocity + (current_angular_velocity * wheel_base / 2.0);
    current_v_right = current_linear_velocity - (current_angular_velocity * wheel_base / 2.0);
    ROS_INFO("current_v_left=%.2f,current_v_right=%.2f",current_v_left,current_v_right);
    // 打印当前速度信息
    ROS_INFO("Current Linear Velocity: %.2f m/s", current_linear_velocity);
    ROS_INFO("Current Angular Velocity: %.2f rad/s", current_angular_velocity);

    // 更新前一次数据
    prev_yaw = current_yaw;
    prev_time = current_time;
    prev_pos_x = pos_x;
    prev_pos_y = pos_y;
}



void goalCallback(const nav_msgs::Odometry::ConstPtr& msg) {
    target_pos_x = msg->pose.pose.position.x;
    target_pos_y = msg->pose.pose.position.y;
    // distance_to_target = sqrt(pow(target_pos_x - pos_x, 2) + pow(target_pos_y - pos_y, 2));
    target_theta = atan2(target_pos_y - pos_y, target_pos_x - pos_x);//
    delta_theta = target_theta - current_yaw;
    d_yaw=delta_theta-last_yaw_error;
    i_yaw=i_yaw+delta_theta;
    last_yaw_error=delta_theta;
    // printf("目标的角度=%.2f\n", target_theta);
    ROS_INFO("target_pos: x=%.2f, y=%.2f, target_theta=%.2f", target_pos_x, target_pos_y, target_theta);
    ROS_INFO("current_pos: x=%.2f, y=%.2f, current_yaw=%.2f", pos_x, pos_y, current_yaw);
}

// void goalCallback(const move_base_msgs::MoveBaseActionGoal::ConstPtr& msg) {

//     ROS_INFO("Received goal: %s", msg->header.stamp.toString().c_str());
// }

int main(int argc, char** argv) {
    ros::init(argc, argv, "motor_control_node");
    ros::NodeHandle nh;
    std::string port = "/dev/ttyUSB1";  // 串口号，需根据实际情况修改
    // // 订阅 cmd_vel 话题
    // ros::Subscriber sub = nh.subscribe<geometry_msgs::Twist>("/cmd_vel", 10, boost::bind(cmdVelCallback, _1, port));
    //订阅/odom话题
    ros::Subscriber odom_sub = nh.subscribe<nav_msgs::Odometry>("/odom", 10, odometryCallback);
    ros::Subscriber goal_sub = nh.subscribe<nav_msgs::Odometry>("/new_goal", 10, goalCallback);
    // ros::Subscriber sub = nh.subscribe<move_base_msgs::MoveBaseActionGoal>("/move_base/goal", 10, goalCallback);
    // 订阅 cmd_vel 话题
    ros::Subscriber sub = nh.subscribe<geometry_msgs::Twist>("/cmd_vel", 10, boost::bind(cmdVelCallback, _1, port));
    //把left_speed，right_speed速度发布到一个话题
    // ros::Publisher pub = nh.advertise<std_msgs::Float32MultiArray>("/motor_speed", 10);
    // ros::Rate loop_rate(10);
    pub =nh.advertise<std_msgs::Float32MultiArray>("/motor_speed", 10);


    ros::spin();
    return 0;
}
