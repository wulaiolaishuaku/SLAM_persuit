#include <ros/ros.h>
#include <geometry_msgs/Twist.h>
#include <serial/serial.h>
#include <cstdint>

// 串口实例
serial::Serial ser;

// 校验和计算函数
uint8_t calculateChecksum(const uint8_t* data, size_t len) {
    uint8_t checksum = 0;
    for (size_t i = 0; i < len; ++i) {
        checksum += data[i];
    }
    return checksum;
}

// 速度控制回调函数
void cmdVelCallback(const geometry_msgs::Twist::ConstPtr& msg) {
    // 构造指令数据包
    uint8_t data[13] = {0xAA, 0x55}; // 包头
    data[2] = 0x01;                  // 默认地址
    data[3] = 0x02;                  // CMD: 整体速度控制模式
    data[4] = 0x04;                  // 数据长度

    // 线速度 (int16, 单位 mm/s)
    int16_t linear_velocity = static_cast<int16_t>(msg->linear.x * 1000); // m/s 转 mm/s
    data[5] = (linear_velocity >> 8) & 0xFF;
    data[6] = linear_velocity & 0xFF;

    // 角速度 (int16, 单位 0.001 rad/s)
    int16_t angular_velocity = static_cast<int16_t>(-msg->angular.z * 1000); // rad/s 转 0.001 rad/s
    data[7] = (angular_velocity >> 8) & 0xFF;
    data[8] = angular_velocity & 0xFF;

    // 功能配置位 (Bit1=1: 运行状态)
    data[9] = 0x02;

    // 保留位
    data[10] = 0x00;

    // 校验和
    data[11] = calculateChecksum(data, 11);

    // 包尾
    data[12] = 0xCC;

    // 通过串口发送指令
    if (ser.isOpen()) {
        ser.write(data, sizeof(data));
        ROS_INFO("Sent control command: linear=%.3f m/s, angular=%.3f rad/s",
                 msg->linear.x, msg->angular.z);
    } else {
        ROS_WARN("Serial port not open. Cannot send control command.");
    }
}

int main(int argc, char** argv) {
    // 初始化 ROS 节点
    ros::init(argc, argv, "cmd_vel_to_serial");
    ros::NodeHandle nh;

    // 串口初始化
    try {
        ser.setPort("/dev/ttyUSB1"); // 根据实际情况设置串口名称
        ser.setBaudrate(115200);
        serial::Timeout to = serial::Timeout::simpleTimeout(1000);
        ser.setTimeout(to);
        ser.open();
    } catch (serial::IOException& e) {
        ROS_ERROR("Unable to open port.");
        return -1;
    }

    if (ser.isOpen()) {
        ROS_INFO("Serial port initialized.");
    } else {
        return -1;
    }

    // 订阅 /cmd_vel 话题
    ros::Subscriber cmd_vel_sub = nh.subscribe("/cmd_vel", 10, cmdVelCallback);

    // ROS 循环
    ros::spin();

    // 关闭串口
    ser.close();
    return 0;
}
