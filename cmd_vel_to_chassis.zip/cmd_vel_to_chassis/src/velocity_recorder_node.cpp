#include <ros/ros.h>
#include <geometry_msgs/Twist.h>
#include <fstream>
#include <string>
#include <iomanip> // 用于格式化时间

class CmdVelRecorder {
public:
    CmdVelRecorder(const std::string& file_name) : file_name_(file_name) {
        // 打开文件
        output_file_.open(file_name_, std::ios::out | std::ios::app);
        if (!output_file_.is_open()) {
            ROS_ERROR("Failed to open file: %s", file_name_.c_str());
            ros::shutdown();
        } else {
            ROS_INFO("Recording /cmd_vel to file: %s", file_name_.c_str());
        }

        // 写入文件头
        output_file_ << "Timestamp,Linear_X,Linear_Y,Linear_Z,Angular_X,Angular_Y,Angular_Z\n";
    }

    ~CmdVelRecorder() {
        if (output_file_.is_open()) {
            output_file_.close();
        }
    }

    void cmdVelCallback(const geometry_msgs::Twist::ConstPtr& msg) {
        if (output_file_.is_open()) {
            // 获取当前时间戳
            ros::Time now = ros::Time::now();
            std::string timestamp = formatTime(now);

            // 写入数据
            output_file_ << timestamp << ","
                         << msg->linear.x << ","
                         << msg->linear.y << ","
                         << msg->linear.z << ","
                         << msg->angular.x << ","
                         << msg->angular.y << ","
                         << msg->angular.z << "\n";

            ROS_INFO("Recorded cmd_vel: linear.x=%.2f, angular.z=%.2f",
                     msg->linear.x, msg->angular.z);
        }
    }

private:
    std::ofstream output_file_;
    std::string file_name_;

    // 格式化时间为字符串
    std::string formatTime(const ros::Time& time) {
        std::stringstream ss;
        std::time_t raw_time = time.sec;
        std::tm* time_info = std::localtime(&raw_time);
        ss << std::put_time(time_info, "%Y-%m-%d %H:%M:%S") << "." << time.nsec / 1000000; // 精确到毫秒
        return ss.str();
    }
};

int main(int argc, char** argv) {
    ros::init(argc, argv, "cmd_vel_recorder");
    ros::NodeHandle nh;

    // 设置输出文件路径
    std::string output_file;
    nh.param<std::string>("/home/orangepi/catkin_ws", output_file, "cmd_vel_log.txt");

    // 创建记录器对象
    CmdVelRecorder recorder(output_file);

    // 订阅 /cmd_vel 话题
    ros::Subscriber cmd_vel_sub = nh.subscribe("/cmd_vel", 10, &CmdVelRecorder::cmdVelCallback, &recorder);

    // ROS 循环
    ros::spin();

    return 0;
}
