#include <ros/ros.h>
#include <geometry_msgs/Twist.h>
#include <stdint.h>
#include <cmath>
#include <serial/serial.h>
#include <std_msgs/Float32MultiArray.h>
#include <nav_msgs/Odometry.h>
#include <tf/tf.h>

// 电机控制协议帧结构体
typedef struct
{
    uint8_t SOF1 = 0x5A;               // 帧头，固定为0x5A
    uint8_t length = 0x11;             // 数据长度，固定为0x11（16字节）
    uint8_t Motor_type = 0x01;         // 电机类型，暂时固定为0x01
    uint8_t lenb = 0x01;               // 使能，暂时固定为0x01
    uint8_t l_speedl;                  // 左轮速度低字节
    uint8_t l_speedh;                  // 左轮速度高字节
    uint8_t ldir;                      // 左轮方向，0顺时针，1逆时针
    uint8_t renb = 0x01;               // 使能，暂时固定为0x01
    uint8_t r_speedl;                  // 右轮速度低字节
    uint8_t r_speedh;                  // 右轮速度高字节
    uint8_t rdir;                      // 右轮方向，0顺时针，1逆时针
    uint8_t mod = 0x00;                // 固定为0x00
    uint8_t motor_switch = 0x00;       // 固定为0x00
    uint8_t electric_current = 0x05;   // 固定为0x05
    uint8_t Voltage_Current = 59;      // 固定为59（电压系数）
    uint8_t suml;                      // CRC低字节
    uint8_t sumh;                      // CRC高字节
} motor_tx;

ros::Publisher pub;

// CRC16 校验函数
uint16_t ModbusCrc16Cal(uint8_t *DataPtr, uint16_t DataCnt) {
    uint16_t CrcWord = 0xFFFF;
    uint8_t CrcI;
    while (DataCnt--) {
        CrcWord ^= (uint16_t)*DataPtr++;
        for (CrcI = 0; CrcI < 8; CrcI++) {
            if (CrcWord & 0x0001) {
                CrcWord >>= 1;
                // CRC16 Polynomial = X16 + X15 + X2 + 1
                CrcWord ^= 0xA001;
            } else {
                CrcWord >>= 1;
            }
        }
    }
    return CrcWord;
}

// 串口发送数据函数
void sendToMotorDriver(motor_tx* tx_buf, const std::string& port) {
    try {
        serial::Serial ser;
        ser.setPort(port);  // 设置串口
        ser.setBaudrate(19200);  // 设置波特率

        // 创建一个 Timeout 对象并设置超时
        serial::Timeout timeout = serial::Timeout::simpleTimeout(1000);
        ser.setTimeout(timeout);  // 设置超时
    
        ser.open();  // 打开串口

        if (ser.isOpen()) {
            ROS_INFO("Serial port opened successfully...");
            // 发送数据
            std::vector<uint8_t> data;
            data.push_back(tx_buf->SOF1);  // 添加帧头
            data.push_back(tx_buf->length);  // 添加数据长度
            data.push_back(tx_buf->Motor_type);  // 电机类型
            data.push_back(tx_buf->lenb);  // 使能
            data.push_back(tx_buf->l_speedl);  // 左轮速度低字节
            data.push_back(tx_buf->l_speedh);  // 左轮速度高字节
            data.push_back(tx_buf->ldir);  // 左轮方向
            data.push_back(tx_buf->renb);  // 右轮使能
            data.push_back(tx_buf->r_speedl);  // 右轮速度低字节
            data.push_back(tx_buf->r_speedh);  // 右轮速度高字节
            data.push_back(tx_buf->rdir);  // 右轮方向
            data.push_back(tx_buf->mod);  // 固定值0x00
            data.push_back(tx_buf->motor_switch);  // 固定值0x00
            data.push_back(tx_buf->electric_current);  // 运行电流固定值0x05
            data.push_back(tx_buf->Voltage_Current);  // 电压系数 固定值59
            data.push_back(tx_buf->suml);  // CRC低字节校验位
            data.push_back(tx_buf->sumh);  // CRC高字节

            // 发送数据
            ser.write(data);
            ROS_INFO("Data sent to motor driver");
        } else {
            ROS_ERROR("Failed to open serial port");
        }
    } catch (serial::IOException& e) {
        ROS_ERROR("Serial communication error: %s", e.what());
    }
}

// 回调函数，处理 cmd_vel 消息
void cmdVelCallback(const geometry_msgs::Twist::ConstPtr& msg, const std::string& port) {

    
    // 小车参数
    geometry_msgs::Twist modified_msg = *msg;
    const double wheel_radius = 0.15;  // 轮子半径 (m)
    // const double wheel_distance = 0.446; // 两轮间距 (m)
    const double wheel_distance = 0.5; // 两轮间距 (m)
    motor_tx tx_buf;
    float max_wheel_speed = 90.0;  // 最大轮速限制

    std_msgs::Float32MultiArray speed_msg;
    if(fabs(modified_msg.angular.z)<0.1)
    {
        modified_msg.angular.z=0;
    }
    // 根据运动学模型计算左右轮速度 (rad/s)
    // double v_left = (2 *  modified_msg.linear.x + modified_msg.angular.z * wheel_distance) / (2 * wheel_radius);
    // double v_right = (2 *  modified_msg.linear.x - modified_msg.angular.z * wheel_distance) / (2 * wheel_radius);
    double v_left = modified_msg.linear.x + (modified_msg.angular.z * wheel_distance) /4;
    double v_right = modified_msg.linear.x - (modified_msg.angular.z * wheel_distance) /4; 
    double w_left = v_left / wheel_radius;
    double w_right = v_right / wheel_radius;

    // 转换为 RPM
    double rpm_left = w_left * 60 / (2 * M_PI)*2;
    double rpm_right = w_right * 60 / (2 * M_PI)*2;
    ROS_INFO("rpm_left: %f,rpm_right: %f",rpm_left,rpm_right);
    
    float max_speed1 = std::max(fabs(rpm_left), fabs(rpm_right));                       
    if (max_speed1 > max_wheel_speed) {
        float scale = max_wheel_speed / max_speed1;
        rpm_left *= scale;
        rpm_right *= scale;
        ROS_INFO("over speed limit, scale: %.2f", scale);
        ROS_INFO("adjusted left speed: %.2f RPM", rpm_left);                                                                          
        ROS_INFO("adjusted right speed: %.2f RPM", rpm_right);                                                                                                                                                                                                                                
    }
    speed_msg.data.resize(2);
    speed_msg.data[0] = rpm_left;
    speed_msg.data[1] = rpm_right;
    pub.publish(speed_msg);
    tx_buf.l_speedl = (uint8_t)((uint16_t)(fabs(rpm_left)) & 0xFF);
    tx_buf.l_speedh = (uint8_t)((uint16_t)(fabs(rpm_left)) >> 8);
    tx_buf.r_speedl = (uint8_t)((uint16_t)(fabs(rpm_right)) & 0xFF);
    tx_buf.r_speedh = (uint8_t)((uint16_t)(fabs(rpm_right)) >> 8);

    // // 设置电机方向（根据速度正负判断）
    tx_buf.ldir = (rpm_left >= 0) ? 1: 0;  // 顺时针为0，逆时针为1
    tx_buf.rdir = (rpm_right >= 0) ? 0: 1;

    // tx_buf.ldir=1;
    // tx_buf.rdir=0;

    // 计算CRC校验
    uint16_t crc = ModbusCrc16Cal((uint8_t*)&tx_buf, sizeof(tx_buf) - 2); // 计算CRC，忽略CRC字段本身
    tx_buf.suml = (uint8_t)(crc & 0xFF);  // CRC低字节

    tx_buf.sumh = (uint8_t)((crc >> 8) & 0xFF);  // CRC高字节

    // 打印调试信息
    ROS_INFO("Sending motor command: SOF1=0x%02X, length=0x%02X, left_speed=%.2f, right_speed=%.2f", 
             tx_buf.SOF1, tx_buf.length, rpm_left, rpm_right);

    // 发送数据到底盘
    sendToMotorDriver(&tx_buf, port);  
}


int main(int argc, char** argv) {
    ros::init(argc, argv, "motor_control_node");
    ros::NodeHandle nh;
    std::string port = "/dev/ttyUSB1";  // 串口号，需根据实际情况修改
 

    ros::Subscriber sub = nh.subscribe<geometry_msgs::Twist>("/cmd_vel", 10, boost::bind(cmdVelCallback, _1, port));

    pub =nh.advertise<std_msgs::Float32MultiArray>("/motor_speed", 10);


    ros::spin();
    return 0;
}
