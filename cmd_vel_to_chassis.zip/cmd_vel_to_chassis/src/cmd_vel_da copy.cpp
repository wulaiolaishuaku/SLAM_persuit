#include <ros/ros.h>
#include <geometry_msgs/Twist.h>
#include <serial/serial.h>
#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>

// 串口对象
serial::Serial serial_port;
geometry_msgs::Twist last_cmd_vel; // 用于存储最后的cmd_vel指令

// 配置串口
void configureSerial(const std::string& port, int baudrate) {
    try {
        serial_port.setPort(port);
        serial_port.setBaudrate(baudrate);
        serial::Timeout timeout = serial::Timeout::simpleTimeout(1000);
        serial_port.setTimeout(timeout);
        serial_port.open();
        if (serial_port.isOpen()) {
            ROS_INFO("Serial port opened successfully.");
        } else {
            ROS_ERROR("Failed to open serial port.");
        }
    } catch (serial::IOException& e) {
        ROS_ERROR("Serial Exception: %s", e.what());
    }
}
// CRC 校验计算
uint8_t calculateCRC(const std::vector<uint8_t>& data) {
    uint8_t crc = 0;
    for (size_t i = 0; i < data.size(); ++i) {
        crc += data[i];
    }
    return crc;
}

// 发送速度指令
void sendVelocityCommand(int16_t left_speed, int16_t right_speed) {
    std::vector<uint8_t> command;
    
    command.push_back(0xAA);  // 包头 1
    command.push_back(0x55);  // 包头 2
    command.push_back(0x01);  // 地址（默认 0x01）
    command.push_back(0x03);  // CMD：两个轮子的线速度独立控制
    command.push_back(0x04);  // 数据长度 (两个轮子的速度 + 功能配置位)

    // 电机 1（左轮）速度
    command.push_back((left_speed >> 8) & 0xFF); // 左轮速度 高 8 位
    command.push_back(left_speed & 0xFF);        // 左轮速度 低 8 位

    // 电机 2（右轮）速度
    command.push_back((right_speed >> 8) & 0xFF); // 右轮速度 高 8 位
    command.push_back(right_speed & 0xFF);        // 右轮速度 低 8 位

    // 功能配置位（进入运行状态）
    command.push_back(0x01);  

    // CRC 校验
    command.push_back(calculateCRC(command));

    // 包尾
    command.push_back(0xCC);

    // 发送指令
    if (serial_port.isOpen()) {
        serial_port.write(command);
        ROS_INFO("Sent command: left_speed=%d, right_speed=%d", left_speed, right_speed);
    } else {
        ROS_ERROR("Serial port is not open.");
    }
    ROS_INFO_STREAM("Sent command: ");
    for (size_t i = 0; i < command.size(); ++i) {
        ROS_INFO_STREAM("0x" << std::hex << (int)command[i]);
    }
}
// cmd_vel 回调函数
void cmdVelCallback(const geometry_msgs::Twist::ConstPtr& msg) {
    last_cmd_vel = *msg; // 保存收到的速度指令
}

// 发送指令的定时器回调函数
void sendCommandTimerCallback(const ros::TimerEvent&) {
    double linear = last_cmd_vel.linear.x;  // 线速度 (m/s)
    double angular = last_cmd_vel.angular.z; // 角速度 (rad/s)

    // 轮子参数
    const double wheel_base = 0.5; // 两轮中心距离 (m)
    const double wheel_radius = 0.15; // 轮子半径 (m)

    // 转换线速度到轮子速度 (mm/s)
    int16_t left_speed = static_cast<int16_t>((linear - angular * wheel_base / 2) * 1000);
    int16_t right_speed = static_cast<int16_t>((linear + angular * wheel_base / 2) * 1000);

    // 限制速度范围
    left_speed = std::max(-1800, std::min(1800, static_cast<int>(left_speed)));
    right_speed = std::max(-1800, std::min(1800, static_cast<int>(right_speed)));

    // 发送速度指令
    sendVelocityCommand(left_speed, right_speed);
}

int main(int argc, char** argv) {
    ros::init(argc, argv, "cmd_vel_to_motor");

    // 使用私有的 NodeHandle
    ros::NodeHandle private_nh("~");

    // 获取参数
    std::string port;
    int baudrate;
    private_nh.param<std::string>("port", port, "/dev/ttyUSB1");
    private_nh.param<int>("baudrate", baudrate, 115200);

    ROS_INFO("Port: %s, Baudrate: %d", port.c_str(), baudrate);

    // 配置串口
    configureSerial(port, baudrate);

    // 公共 NodeHandle，用于话题订阅和发布
    ros::NodeHandle nh;

    // 订阅 /cmd_vel 话题
    ros::Subscriber cmd_vel_sub = nh.subscribe("/cmd_vel", 10, cmdVelCallback);

    // 设置定时器，每100ms发布一次指令，相当于10Hz的频率
    ros::Timer send_command_timer = nh.createTimer(ros::Duration(0.1), sendCommandTimerCallback);

    // 循环
    ros::spin();

    return 0;
}
