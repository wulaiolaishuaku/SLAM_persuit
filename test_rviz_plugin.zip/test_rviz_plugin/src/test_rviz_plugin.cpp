#include <test_rviz_plugin/test_rviz_plugin.h>
#include <std_msgs/String.h>
#include <geometry_msgs/PoseStamped.h>
#include <tf/transform_listener.h>
#include <nav_msgs/Odometry.h>
#include <fstream>
#include <yaml-cpp/yaml.h>
#include <QProcess>
namespace test_rviz_plugin{
    Function::Function(QWidget *parent):Panel(parent)
    {   
    	//创建两个按钮---测试按钮和测试按钮2
        // auto *button_layout = new QHBoxLayout;
        setlocale(LC_CTYPE, "zh_CN.utf8");
        layout_ = new QVBoxLayout;
        // // 创建 "Packing point" 按钮
        record_button_  = new QPushButton(tr("Packing Point"),this);
        layout_->addWidget(record_button_);

        follow_button_ = new QPushButton(tr("Start following"), this);
        pack_button_ = new QPushButton(tr("Start packing"), this);
        layout_->addWidget(follow_button_);
        layout_->addWidget(pack_button_);
        setLayout(layout_);
        // 初始化进程指针
        follow_process_ = nullptr;
    
        //信号连接---点击信号发生，连接到槽函数test_callback()
        connect(record_button_,SIGNAL(clicked()),this,SLOT(recordPosition()));
        // connect(publish_button_,SIGNAL(clicked()),this,SLOT(publishPosition()));
        // 连接按钮信号
        connect(follow_button_, &QPushButton::clicked, this, &Function::startFollow);
        connect(pack_button_, &QPushButton::clicked, this, &Function::startPack);
		// 初始化发布者和订阅者
        goal_pub_ = nh_.advertise<geometry_msgs::PoseStamped>("/move_base_simple/goal", 10);
        pose_sub_ = nh_.subscribe("/carto_odom", 1, &Function::poseCallback, this);
        marker_pub_ = nh_.advertise<visualization_msgs::Marker>("/visualization_marker", 10); // 初始化 Marker 发布者
        loadSavedPositions();
    }

    void Function::loadSavedPositions() {
        std::string file_path = "/home/wt/DownLoads/saved_position.yaml";
        try {
            YAML::Node config = YAML::LoadFile(file_path);
            
            if (config["position"]) {
                YAML::Node positions = config["position"];
                for (size_t i = 0; i < positions.size(); ++i) {
                    // 解析YAML节点
                    YAML::Node pos = positions[i];
                    geometry_msgs::PoseStamped pose_stamped;
                    pose_stamped.header.frame_id = "map";
                    pose_stamped.pose.position.x = pos["x"].as<double>();
                    pose_stamped.pose.position.y = pos["y"].as<double>();
                    pose_stamped.pose.position.z = pos["z"].as<double>();
                    
                    // 保存到列表
                    saved_poses_.push_back(pose_stamped);
                    
                    // 创建对应按钮
                    QPushButton *btn = new QPushButton(
                        QString("Go to point %1").arg(i+1), 
                        this
                    );
                    layout_->addWidget(btn);
                    
                    // 绑定按钮事件（注意正确捕获索引）
                    const int index = i;
                    connect(btn, &QPushButton::clicked, [this, index]() {
                        publishPosition(index);
                    });
                    
                    // 发布可视化标记
                    publishMarker(index, pose_stamped);
                }
                ROS_INFO("Successfully loaded %zu packing points.", positions.size());
            }
        } catch (const YAML::Exception& e) {
            ROS_WARN_STREAM("YAML parsing error: " << e.what());
        } catch (const std::exception& e) {
            ROS_ERROR_STREAM("Failed to load positions: " << e.what());
        }
    }
    
    // 启动跟随功能
    void Function::startFollow() {
        if (!follow_process_) {
            follow_process_ = new QProcess(this);
            QString program = "rosrun";
            QStringList arguments;
            arguments << "add_position_to_odom" << "add_position_to_odom";
            follow_process_->start(program, arguments);

            if (follow_process_->state() == QProcess::Running) {
                ROS_WARN("The follow function has been activated");
            } else {
                ROS_ERROR("The follow function cannot be started!");
            }
        }
    }

    // 启动打包功能（停止跟随）
    void Function::startPack() {
        if (follow_process_ && follow_process_->state() == QProcess::Running) {
            // follow_process_->terminate();  // 发送终止信号
            follow_process_->kill(); 
            follow_process_->waitForFinished(1000); // 等待1秒
            if (follow_process_->state() == QProcess::NotRunning) {
                ROS_WARN("The follow function cannot be started!");
            } else {
                ROS_ERROR("The termination process failed, and an attempt was made to force the termination!");
                system("pkill -9 -f 'add_position_to_odom'");  // 强制终止
            }
            delete follow_process_;
            follow_process_ = nullptr;
            ROS_WARN("The follow function has been discontinued");
        }
    }
    //加载配置数据---必须要有的
    void Function::load(const rviz::Config &config){
        Panel::load(config);
    }
    void Function::publishMarker(int index, const geometry_msgs::PoseStamped& pose) {
        visualization_msgs::Marker marker;
    
        // 设置标记的头部信息
        marker.header.frame_id = "map"; // 坐标系
        marker.header.stamp = ros::Time::now();
    
        // 设置标记的命名空间和 ID
        marker.ns = "Point";
        marker.id = index; // 标记的 ID
    
        // 设置标记类型为文本
        marker.type = visualization_msgs::Marker::TEXT_VIEW_FACING;
    
        // 设置标记的动作为添加/修改
        marker.action = visualization_msgs::Marker::ADD;
    
        // 设置标记的位置
        marker.pose.position.x = pose.pose.position.x;
        marker.pose.position.y = pose.pose.position.y;
        marker.pose.position.z = pose.pose.position.z + 0.5; // 将文本稍微抬高
        marker.pose.orientation.w = 1.0;
    
        // 设置标记的文本内容
        marker.text = std::to_string(index + 1); // 显示 "1", "2", "3" 等
    
        // 设置标记的尺寸
        marker.scale.z = 0.5; // 文本高度
    
        // 设置标记的颜色
        marker.color.r = 1.0; // 红色
        marker.color.g = 0.0;
        marker.color.b = 0.0;
        marker.color.a = 1.0; // 不透明度
    
        // 设置标记的生存时间（0 表示永久）
        marker.lifetime = ros::Duration();
    
        // 发布标记
        marker_pub_.publish(marker);
    }
    //将所有配置数据保存到给定的Config对象中。在这里，重要的是要对父类调用save（），以便保存类id和面板名称。---必须要有的
    void Function::save(rviz::Config config) const{
        Panel::save(config);
    }
    // 记录机器人当前位置的回调函数
    void Function::poseCallback(const nav_msgs::Odometry::ConstPtr &msg) {
        current_pose_ = msg->pose.pose; // 保存当前位置
    }
    // "Packing point" 按钮的回调函数
    void Function::recordPosition() {
        geometry_msgs::PoseStamped pose_stamped;
        pose_stamped.header.stamp = ros::Time::now(); // 设置时间戳
        pose_stamped.header.frame_id = "map"; // 设置坐标系
        pose_stamped.pose = current_pose_; // 复制位置信息
        // 定义文件路径
        saved_poses_.push_back(pose_stamped);
        ROS_WARN("Position added to list! Current number of points: %zu", saved_poses_.size());
        // 发布标记
        int index1 = saved_poses_.size() - 1;
        publishMarker(index1, pose_stamped);
        // 创建新的按钮
        int index = saved_poses_.size(); // 按钮的编号
        QPushButton *publish_button = new QPushButton(QString("go to point %1").arg(index), this);
        layout_->addWidget(publish_button);
        // 使用 lambda 表达式绑定按钮点击信号
        connect(publish_button, &QPushButton::clicked, this, [this, index]() {
            this->publishPosition(index - 1); // 索引从 0 开始
        });
        std::string file_path = "//home/wt/DownLoads/saved_position.yaml";
        // 创建 YAML 节点
        YAML::Emitter emitter;
        emitter << YAML::BeginMap;
        emitter << YAML::Key << "position";
        emitter << YAML::Value << YAML::BeginSeq;
        for (const auto &pose : saved_poses_) {
            emitter << YAML::BeginMap;
            emitter << YAML::Key << "x" << YAML::Value << pose.pose.position.x;
            emitter << YAML::Key << "y" << YAML::Value << pose.pose.position.y;
            emitter << YAML::Key << "z" << YAML::Value << pose.pose.position.z;
            emitter << YAML::EndMap;
        }
        emitter << YAML::EndSeq;
        emitter << YAML::EndMap;
        // 写入文件
        std::ofstream file(file_path);
        if (file.is_open()) {
            file << emitter.c_str();
            file.close();
            ROS_WARN("Position saved to file: %s", file_path.c_str());
        } else {
            ROS_ERROR("Failed to open file for saving position!");
        }
        // 标记位置已保存
        // is_position_saved_ = true;
        // 启用发布按钮
        // publish_button_->setEnabled(true);
    }

    void Function::publishPosition(int index) {
        // 检查索引是否有效
        if (index < 0 || index >= saved_poses_.size()) {
            ROS_ERROR("Invalid index: %d", index);
            return;
        }
        // 获取对应的点
        geometry_msgs::PoseStamped goal_msg = saved_poses_[index];
        goal_msg.header.stamp = ros::Time::now(); // 更新时间戳
        // 发布位置
        goal_pub_.publish(goal_msg);
        ROS_WARN("Position %d published to /move_base_simple/goal: x=%f, y=%f, z=%f",
                index + 1, goal_msg.pose.position.x, goal_msg.pose.position.y, goal_msg.pose.position.z);
    }
}
#include <pluginlib/class_list_macros.h>
PLUGINLIB_EXPORT_CLASS(test_rviz_plugin::Function,rviz::Panel)