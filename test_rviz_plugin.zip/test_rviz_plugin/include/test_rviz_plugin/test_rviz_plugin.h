#ifndef TEST_RVIZ_PLUGIN_H
#define TEST_RVIZ_PLUGIN_H

#include <rviz/panel.h>
#include <ros/ros.h>
#include <QWidget>
#include <QVBoxLayout>
#include <QPushButton>
#include <QProcess>
#include <geometry_msgs/PoseStamped.h>
#include <nav_msgs/Odometry.h>
#include <visualization_msgs/Marker.h>
#include <yaml-cpp/yaml.h>

namespace test_rviz_plugin
{
class Function : public rviz::Panel
{
  Q_OBJECT
public:
  Function(QWidget* parent = 0);
  virtual ~Function() = default;

  virtual void load(const rviz::Config& config);
  virtual void save(rviz::Config config) const;

private Q_SLOTS:
  void recordPosition();
  void startFollow();
  void startPack();

private:
  void loadSavedPositions();
  void publishMarker(int index, const geometry_msgs::PoseStamped& pose);
  void publishPosition(int index);
  void poseCallback(const nav_msgs::Odometry::ConstPtr& msg);

  // UI Components
  QVBoxLayout* layout_;
  QPushButton* record_button_;
  QPushButton* follow_button_;
  QPushButton* pack_button_;

  // ROS Components
  ros::NodeHandle nh_;
  ros::Publisher goal_pub_;
  ros::Publisher marker_pub_;
  ros::Subscriber pose_sub_;
  
  // Data Storage
  std::vector<geometry_msgs::PoseStamped> saved_poses_;
  geometry_msgs::Pose current_pose_;
  
  // Process Control
  QProcess* follow_process_;
};

} // namespace test_rviz_plugin

#endif // TEST_RVIZ_PLUGIN_H