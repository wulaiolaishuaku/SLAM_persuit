#include <ros/ros.h>
#include <std_msgs/UInt8.h>
#include <std_msgs/UInt32.h>
class TagStatusCounter {
public:
    TagStatusCounter() : prev_status_initialized_(false), count_(0) {
        sub_ = nh_.subscribe("/tag_status", 10, &TagStatusCounter::statusCallback, this);
        pub_ = nh_.advertise<std_msgs::UInt32>("/tag_status_count", 10);
    }
    void statusCallback(const std_msgs::UInt8::ConstPtr& msg) {
        uint8_t current_status = msg->data;
        if (!prev_status_initialized_) {
            prev_status_ = current_status;
            prev_status_initialized_ = true;
            return;
        }
        if (prev_status_ == 0 || prev_status_ == 1) {
            if ( current_status == 128 || current_status == 129 ){
                count_++;
                std_msgs::UInt32 count_msg;
                count_msg.data = count_;
                pub_.publish(count_msg);
                ROS_INFO("Count increased to: %u", count_);
            }
            // count_++;
            // std_msgs::UInt32 count_msg;
            // count_msg.data = count_;
            // pub_.publish(count_msg);
            // ROS_INFO("Count increased to: %u", count_);
        }
        prev_status_ = current_status;
    }

private:
    ros::NodeHandle nh_;
    ros::Subscriber sub_;
    ros::Publisher pub_;
    bool prev_status_initialized_;
    uint8_t prev_status_;
    uint32_t count_; 
};

int main(int argc, char** argv) {
    ros::init(argc, argv, "tag_status_counter");
    TagStatusCounter counter;
    ros::spin();
    return 0;
}