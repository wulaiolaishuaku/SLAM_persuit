#include <ros/ros.h>
#include <std_msgs/UInt32.h>
#include <nav_msgs/Odometry.h>
#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/Twist.h>
#include <mutex>

class StatusController {
private:
  ros::NodeHandle nh_;
  ros::Subscriber count_sub_;
  ros::Subscriber odom_sub_;
  ros::Publisher goal_pub_;
  ros::Subscriber goal_sub_;
  uint32_t last_count_ = 0;
  geometry_msgs::PoseStamped current_pose_;
  geometry_msgs::PoseStamped captured_goal_;  // ����ż����ʱ��Ŀ��λ��
  geometry_msgs::PoseStamped last_even_goal_; // �洢��һ��ż����Ŀ��λ��
  bool capture_required_ = true;  //�����־
  bool pose_updated_ = false;
  std::mutex data_mutex_;
  uint32_t  count;

public:
  StatusController() {
    count_sub_ = nh_.subscribe("/tag_status_count", 10, &StatusController::countCallback, this);
    odom_sub_ = nh_.subscribe("/carto_odom", 1, &StatusController::odomCallback, this);
    goal_sub_ = nh_.subscribe("/move_base_simple/goal", 1, &StatusController::goalCallback, this);
    goal_pub_ = nh_.advertise<geometry_msgs::PoseStamped>("/move_base_simple/goal", 1);
  }

  // Ŀ��λ�ö��Ļص�
  void goalCallback(const geometry_msgs::PoseStamped::ConstPtr& msg) {
    std::lock_guard<std::mutex> lock(data_mutex_);
    // ������Ҫ����ʱ����Ŀ��λ��
    if (capture_required_) {
      captured_goal_ = *msg;
      capture_required_ = false;  // ���ñ�־
    }
    // ������һ��ż����Ŀ��λ��
    if (last_count_ % 2 == 0) {
      last_even_goal_ = *msg;
    }
  }

  void odomCallback(const nav_msgs::Odometry::ConstPtr& msg) {
    current_pose_.header.stamp = ros::Time::now();
    current_pose_.header.frame_id = "map";  // ͨ��Ϊ "odom" �� "map"
    current_pose_.pose = msg->pose.pose;
    pose_updated_ = true;
  }
  
  void countCallback(const std_msgs::UInt32::ConstPtr& msg) {
    count = msg->data;
    // ������ż�¼�
    if ((last_count_ % 2 == 1) && (msg->data % 2 == 0)) {
      std::lock_guard<std::mutex> lock(data_mutex_);
      capture_required_ = true;  // ���ò����־
      ROS_WARN("Even to odd transition detected, capturing goal...");
    }
    if (msg->data % 2 == 1) {
      if(pose_updated_) {
        current_pose_.header.stamp = ros::Time::now();
        goal_pub_.publish(current_pose_);
        ROS_WARN("Emergency stop triggered! Current position set as goal.");
      }
    }
    else {
      // ��msg->dataΪż��ʱ��������һ��ż����Ŀ��λ��
      std::lock_guard<std::mutex> lock(data_mutex_);
      last_even_goal_.header.stamp = ros::Time::now();
      goal_pub_.publish(last_even_goal_);
      ROS_WARN("Last even goal published: %.2f, %.2f", last_even_goal_.pose.position.x, last_even_goal_.pose.position.y);
    }
    last_count_ = msg->data;
  }
};

int main(int argc, char** argv) {
  ros::init(argc, argv, "status_controller");
  StatusController controller; // �������󣬳�ʼ�����ĺͷ���
  ros::spin(); //ѭ������
  return 0;
}