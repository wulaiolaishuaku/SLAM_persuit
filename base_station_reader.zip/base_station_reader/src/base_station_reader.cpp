#include <ros/ros.h>
#include <geometry_msgs/Point.h>
#include <serial/serial.h>
#include <iostream>
#include <vector>
#include <array>
#include <thread>
#include <chrono>
#include <std_msgs/UInt8.h>
#include <std_msgs/UInt32.h>  
// 帧头和帧长度
const uint8_t FRAME_HEADER_1 = 0x5A;
const uint8_t FRAME_HEADER_2 = 0xA5;
const size_t FRAME_LENGTH = 40;  // 每帧固定23字节
bool tag_state = false;
std_msgs::UInt8 msg;
std_msgs::UInt8 msg_x;
std_msgs::UInt8 msg_y;
uint8_t current_tag_status = 0x00;
// 数据解析函数
// std::string alarm_command = "ALARM " + std::to_string(command) + "\r\n";
void send_alarm_command(serial::Serial& ser, uint8_t command) {
    // 将命令转换为字符串，添加 "\r\n" 结尾
    std::string alarm_command = "ALARM " + std::to_string(command) + "\r\n";
    
    try {
        // 发送命令
        ser.write(alarm_command);
        // ROS_INFO("成功发送命令: %s", alarm_command.c_str());
    } catch (const serial::IOException& e) {
        // ROS_ERROR("发送命令失败: %s", e.what());
    }
}
geometry_msgs::Point parsePositionData(const std::vector<uint8_t>& data) {
    geometry_msgs::Point position;
    position.x = 0.0;
    position.y = 0.0;
    position.z = 0.0;

    uint8_t tag_status = 0;  // 用于存储标签状态位
    uint8_t joy_msg_x = 0;
    uint8_t joy_msg_y = 0;

    try {
        // 检查帧头
        if (data[0] != FRAME_HEADER_1 || data[1] != FRAME_HEADER_2) {
            ROS_ERROR("帧头错误");
            return position;
        }

        // 提取X和Y坐标（小端模式，单位厘米）
        int16_t x = static_cast<int16_t>(data[5] | (data[6] << 8));  // X坐标 左移8位
        int16_t y = static_cast<int16_t>(data[7] | (data[8] << 8));  // Y坐标 右移8位

        position.x = y / 100.0;  // 转换为米单位
        position.y = x / 100.0;

        // 读取第17个字节作为标签状态位
        tag_status = data[16];  //
        current_tag_status = tag_status;
        joy_msg_x = data[14];
        joy_msg_y = data[15];
        msg_x.data = joy_msg_x;
        msg_y.data = joy_msg_y;
        // ROS_INFO("tag_status: %d", tag_status);
        msg.data = tag_status;
        if (tag_status == 0) {
            // ROS_INFO("标签状态: 正常");
            tag_state = true;
        } else {
            // ROS_WARN("标签状态: 异常");
            // ROS_WARN("标签状态: 异常, 状态值 = %d", tag_status);
            tag_state = false;
        } 
    } catch (const std::exception& e) {
        ROS_ERROR("数据解析失败: %s", e.what());
    }

    return position;
}

int main(int argc, char** argv) {
    setlocale(LC_ALL, "");  
    ros::init(argc, argv, "base_station_reader");
    ros::NodeHandle nh("~");

    // 获取参数
    std::string port;
    int baudrate;
    nh.param<std::string>("port", port, "/dev/ttyUSB2");  // 默认串口设备
    nh.param<int>("baudrate", baudrate, 115200);          // 默认波特率

    // 发布器
    ros::Publisher pub = nh.advertise<geometry_msgs::Point>("/base_station_position", 10);
    ros::Publisher tag_status_pub = nh.advertise<std_msgs::UInt8>("/tag_status", 10);
    ros::Publisher joystick_x_pub = nh.advertise<std_msgs::UInt8>("/joystick_y", 10);
    ros::Publisher joystick_y_pub = nh.advertise<std_msgs::UInt8>("/joystick_x", 10);

    // 配置串口
    serial::Serial ser;
    try {
        ser.setPort(port);
        ser.setBaudrate(baudrate);
        serial::Timeout timeout = serial::Timeout::simpleTimeout(100);
        ser.setTimeout(timeout);
        ser.open();
        if (!ser.isOpen()) {
            ROS_ERROR("无法打开串口: %s", port.c_str());
            return -1;
        }

        ROS_INFO("串口打开成功，开始读取数据...");
    } catch (const serial::IOException& e) {
        ROS_ERROR("串口打开失败: %s", e.what());
        return -1;
    }
    ros::Subscriber tag_status_count_sub = nh.subscribe<std_msgs::UInt32>("/tag_status_count", 10, [&](const std_msgs::UInt32::ConstPtr& msg) {
        uint8_t new_status = current_tag_status;
        if (msg->data % 2 == 1) {
            // 奇数，设置bit0为1（电源灯亮）
            new_status |= 0x01;
        } else {
            // 偶数，清除bit0为0（电源灯灭）
            new_status &= ~0x01;
        }
        // 发送新的状态
        send_alarm_command(ser, new_status);
    });
    ros::Rate rate(10);  // 提高发布频率至50Hz
    std::vector<uint8_t> buffer;

    while (ros::ok()) {
        try {
            if (ser.available()) {
                // 批量读取数据
                std::string new_data = ser.read(ser.available());
                buffer.insert(buffer.end(), new_data.begin(), new_data.end());
                // 搜索帧头并解析完整帧
                while (buffer.size() >= FRAME_LENGTH) {
                    // 匹配帧头
                    std::array<uint8_t, 2> frame_header = {FRAME_HEADER_1, FRAME_HEADER_2};
                    auto it = std::search(buffer.begin(), buffer.end(), frame_header.begin(), frame_header.end());
                    if (it != buffer.end()) {
                        // 找到帧头位置，检查是否有足够数据组成完整帧
                        size_t header_index = std::distance(buffer.begin(), it);
                        if (buffer.size() >= header_index + FRAME_LENGTH) {
                            // 提取完整帧数据
                            std::vector<uint8_t> frame(buffer.begin() + header_index,
                                                       buffer.begin() + header_index + FRAME_LENGTH);
                            // 删除已处理数据
                            buffer.erase(buffer.begin(), buffer.begin() + header_index + FRAME_LENGTH);
                            // 解析并发布位置信息
                            geometry_msgs::Point position = parsePositionData(frame);
                            pub.publish(position);
                            tag_status_pub.publish(msg);
                            joystick_x_pub.publish(msg_x);
                            joystick_y_pub.publish(msg_y);
                            // send_alarm_command(ser, 00);
                            std::this_thread::sleep_for(std::chrono::milliseconds(100));
                            ROS_INFO("发布位置信息: x=%.2f, y=%.2f", position.x, position.y);
                        } else {
                            // 数据不完整，等待下一次读取
                            break;
                        }
                    } else {
                        // 没有找到帧头，清除无效数据
                        buffer.clear();
                        break;
                    }
                }
            }
        } catch (const std::exception& e) {
            ROS_ERROR("读取或解析数据失败: %s", e.what());
        }
        ros::spinOnce();
        rate.sleep();
    }
    ser.close();
    return 0;
}









